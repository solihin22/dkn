<?php
defined('BASEPATH') OR die('No direct script access allowed!');

class Data_Chart 
{
    private $CI;
    private $model;

    public function __construct()
    {
        $this->CI =& get_instance();
        $this->CI->load->model('Chart_Model');
        $this->model = $this->CI->Chart_Model;
    }

    public function all_data($year = '')
    {
        if ($year == '') $year = date('Y');
        $data['sarpras'] = $this->data_all_sarpras($year);
        $data['sdm'] = $this->data_all_sdm($year);
        $data['arsip'] = $this->data_all_arsip($year);
        $data['anggaran'] = $this->data_all_anggaran($year);
        $data['gnsta'] = $this->data_count_gnsta($year);
        return $data;
    }

    public function data_all_sarpras($year = '')
    {
        if ($year == '') $year = date('Y');
        $sarpras = $this->model->all_data_sarpras($year);
        $data = $this->store_data($sarpras, 'id_sarana');
        return $data;
    }

    public function data_all_sdm($year = '')
    {
        if ($year == '') $year = date('Y');
        $sdm = $this->model->all_data_sdm($year);
        $data = $this->store_data($sdm, 'id_sdm');
        return $data;
    }

    public function data_all_arsip($year = '')
    {
        if ($year == '') $year = date('Y');
        $arsip = $this->model->all_data_arsip($year);
        $data = $this->store_data($arsip, 'id_data_arsip');
        return $data;
    }

    public function data_all_anggaran($year = '')
    {
        if ($year == '') $year = date('Y');
        $anggaran = $this->model->all_data_anggaran($year);
        $data = $this->store_data($anggaran, 'id_anggaran');
        return $data;
    }
    
    public function data_count_gnsta($year)
    {
        if ($year == '') $year = date('Y');
        $gnsta = $this->model->all_data_gnsta($year);
        $data = $this->store_data($gnsta, 'id_gnsta');
        return $data;
    }

    public function store_data($dump_data, $primary_id)
    {
        $data = [];
        foreach ($dump_data as $s) {
            $data[$s->username] = 0;
            foreach ($s as $sv => $vs) {
                if ($sv == 'tahun' || $sv == $primary_id || $sv == 'username') {
                    continue;
                }
                $data[$s->username] += $vs;
            }
        }
        return $data;
    }
}


