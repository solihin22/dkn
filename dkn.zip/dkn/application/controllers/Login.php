<?php
defined('BASEPATH') OR die('No direct script access allowed!');

/**
* 
*/
class Login extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('status')) {
			redirect($this->session->userdata('status'));
		}
	}

	public function index()
	{
		$this->load->view('user/login');
	}
	public function admin()
	{
		$this->load->view('admin/index');
	}

	public function aksi_login_user()
	{
		$this->load->model('Usermodel');
		$username = $this->input->post('username');
		$password = md5($this->input->post('password'));
		$where = array(
			'username' => $username,
			'password' => $password
		);

		$cek = $this->Usermodel->cek_login("user",$where)->num_rows();

		if($cek > 0){
			$datauser = array(
				'username' => $username,
				'status' => 'user'
			);
			echo $datauser['username'];
			$this->session->set_userdata($datauser);
			redirect(base_url("index.php/user/"));
		}else{
			// echo "Gagal !";
			$this->session->set_flashdata(['error' => 'Login Gagal! <br>Cek Username dan Password']);
			redirect(base_url("index.php/login"));
		}
		// $this->load->view('admin/home');
	}
	public function aksi_login_admin(){
		$this->load->model('Adminmodel');
		$username = $this->input->post('username');
		$password = md5($this->input->post('password'));
		$where = array(
			'username' => $username,
			'password' => $password
			);
		$cek = $this->Adminmodel->cek_login("admin",$where)->num_rows();
		echo $cek;
		if($cek > 0){
			$datauser = array(
				'username' => $username,
				'status' => 'admin'
			);
			echo $datauser['username'];
			$this->session->set_userdata($datauser);
			redirect(base_url("index.php/admin/"));
			
		}else{
			$this->session->set_flashdata(['error' => 'Login Gagal! <br>Cek Username dan Password']);
			redirect(base_url("index.php/login/admin"));
		}
		//$this->load->view('admin/home');
	}
	public function daftar()
	{
	$this->load->model('Usermodel');
		$data1 = [
			'username' => $this->input->post('username'),
			'password' => md5($this->input->post('password')),
			'nama_lkd' => $this->input->post('nama_lkd'),
			'wilayah' => $this->input->post('wilayah'),
			'statuswilayah' => $this->input->post('statuswilayah'),
			'nomenklatur' => $this->input->post('nomenklatur'),
			'dasarhukum' => $this->input->post('dasarhukum'),
			'alamat' => $this->input->post('alamat'),
			'telp' => $this->input->post('telp'),
			'email' => $this->input->post('email'),
			'website' => $this->input->post('website'),
		];		
		$result = $this->Usermodel->daftar($data1);
		if($result){
			echo "Berhasil";
			redirect(base_url());
		}else{
			echo "Gagal !";
		}
	}
	public function daftar_baru()
	{
	$this->load->model('Usermodel');
		$data1 = [
			'username' => $this->input->post('username'),
			'password' => md5($this->input->post('password')),
			'nama' => $this->input->post('nama'),
			'jabatan' => $this->input->post('jabatan'),
			'no_hp' => $this->input->post('no_hp'),
		];	
		$data2 = [
			'username' => $this->input->post('username'),
			'nomenklatur' => $this->input->post('nomenklatur'),
			'nama_kepala' => $this->input->post('nama_kepala'),
			'alamat' => $this->input->post('alamat'),
			'telpfaks' => $this->input->post('telpfaks'),
			'email' => $this->input->post('email'),
			'website' => $this->input->post('website'),
			'status' => $this->input->post('status'),
		];	
		$result = $this->Usermodel->userbaru($data1);
		$result = $this->Usermodel->kelembagaan($data2);
		if($result){
			echo "Berhasil";
			redirect(base_url());
		}else{
			echo "Gagal !";
		}
	}
}
