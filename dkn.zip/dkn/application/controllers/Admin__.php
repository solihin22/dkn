<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Admin extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('form_validation');

		if (!$this->session->userdata('status')) {
			redirect('login');
		}

		if ($this->session->userdata('status') !== 'admin') {
			redirect($this->session->userdata('status'));
		}
	}

	public function logout () {
		$this->session->sess_destroy();
		redirect ('admin/index');
	}

	public function home()
	{
		$this->load->library('data_chart');
		$data['tahun'] = $this->input->get('tahun')? $this->input->get('tahun') : 2019;
		$data['active'] = "active";
		$data['judul'] = "Selamat Datang di Aplikasi DKN";
		
		$data['chart'] = $this->data_chart->all_data($data['tahun']);

		$this->load->view('template/header',$data);
		$this->load->view('admin/home', $data);
		$this->load->view('template/footer',$data);
	}

	public function home2()
	{
		$this->load->library('data_chart');
		$data['tahun'] = $this->input->get('tahun') ? $this->input->get('tahun') : 2019;
		$data['active'] = "active";
		$data['judul'] = "Selamat Datang di Aplikasi DKN";
		$y = date('Y');
		
		for ($i=$y-2; $i <= $y; $i++) {
			$data_chart[$i] = $this->data_chart->all_data($i);
			$data['year_range'][] = $i;
		}
		foreach ($data_chart as $thn => $item) {
			foreach ($item as $i => $lkd) {
				foreach ($lkd as $l => $v) {
					if ($v == '') {
						$data['chart'][$i][$l][$thn] = 0;
					}
					$data['chart'][$i][$l][$thn] = $v;
				}
			}
		}
		
		// echo "<pre>";
		// print_r( $data_chart);
		// print_r($data['chart']);
		// print_r($data['year_range']);
		// echo "</pre>";

		$this->load->view('template/header', $data);
		$this->load->view('admin/home2', $data);
		$this->load->view('template/footer', $data);
	}

	public function grafik()
	{
		$data['active'] = "active";
		$data['judul'] = "Selamat Datang di Aplikasi DKN";
		$this->load->view('template/header',$data);
		$this->load->view('admin/chart');
		$this->load->view('template/footer',$data);
	}
	public function lembaga()
	{
		$data['active'] = "active";
		$data['judul'] = "Data Lembaga Kearsipan";
		$this->load->model('Adminmodel');
		$this->load->view('template/header', $data);
		$records = $this->Adminmodel->datalembaga();
		$this->load->view('admin/lembaga',['records'=>$records]);
		$this->load->view('template/footer');
	}
	public function print_lembaga()
	{
		$this->load->model('Adminmodel');
		$records = $this->Adminmodel->datalembaga();
		$this->load->view('admin/print_lembaga', ['records' => $records]);
	}
	public function reset_password()
	{
		$username = $this->uri->segment(3);
		$data['active'] = "active";
		$data['judul'] = "Reset Password Lembaga " . $username;
		$this->load->model('Adminmodel');
		$this->load->view('template/header', $data);
		$records = $this->Adminmodel->datalembaga($username);
		$this->load->view('admin/reset_pass', ['records' => $records]);
		$this->load->view('template/footer');
	}
	public function aksi_reset_password()
	{
		$new_password = $this->input->post('new_password');
		$repeat_password = $this->input->post('repeat_new_password');
		$username = $this->input->post('username');
		if ($new_password !== $repeat_password) {
			$this->session->set_flashdata(['warning' => 'Password tidak sama']);
			redirect('admin/reset_password/' . $username);
		} else {
			$this->load->model('Usermodel');
			$data = ['password' => $new_password];
			$this->Usermodel->updateprofil($data, $username);
			$this->session->set_flashdata(['success' => 'Password telah diupdate']);
			redirect('admin/lembaga/');
		}
	}
	public function sarpras()
	{
		$data['active'] = "active";
		$data['judul'] = "Data Sarana Prasarana";
		$this->load->model('Adminmodel');
		$this->load->view('template/header', $data);
		$records = $this->Adminmodel->datasarpras();
		$this->load->view('admin/sarpras',['records'=>$records]);
		$this->load->view('template/footer');
	}
	public function detail_sarpras()
	{
		$data['active'] = "active";
		$data['judul'] = "Data Sarana Prasarana";
		
		$this->load->model('Adminmodel');
		$id_sarpras = $this->uri->segment(3);
		$data_record = $this->Adminmodel->datasarpras($id_sarpras)[0];
		$record = $this->clean_data($data_record, 'id_sarana');
		$sub_data = ['username' => $data_record->username, 'tahun' => $data_record->tahun];
		$field = [
			'Central File Filling Kabinet',
			'Central File Folder',
			'Central File Guide',
			'Central File Map Gantung',
			'Central File Out Indikator',
			'Central File Buku Peminjaman',
			'Record Center Rak Arsip',
			'Record Center Boks',
			'Record Center Folder',
			'Record Center Out Indikator',
			'Record Center Buku Peminjaman',
			'DEPO Rak Arsip',
			'DEPO Boks',
			'DEPO Folder',
			'DEPO Out Indikator',
			'DEPO Buku Peminjaman'
		];
		
		$this->load->view('template/header', $data);
		$this->load->view('admin/chart_sarpras', ['record' => $record, 'sub_data' => $sub_data, 'field' => $field]);
		$this->load->view('template/footer');
	}
	public function sdm()
	{
		$data['active'] = "active";
		$data['judul'] = "Data SDM Arsiparis";
		$this->load->model('Adminmodel');
		$this->load->view('template/header', $data);
		$records = $this->Adminmodel->datasdm();
		$this->load->view('admin/sdm',['records'=>$records]);
		$this->load->view('template/footer');
	}
	public function detail_sdm()
	{
		$data['active'] = "active";
		$data['judul'] = "Data SDM";

		$this->load->model('Adminmodel');
		$id_sdm = $this->uri->segment(3);
		$data_record = $this->Adminmodel->datasdm($id_sdm)[0];
		$record = $this->clean_data($data_record, 'id_sdm');
		$sub_data = ['username' => $data_record->username, 'tahun' => $data_record->tahun];
		$field = [
			'Arsiparis Terampil Pelaksana',
			'Arsiparis Terampil Pelaksana Lanjutan',
			'Arsiparis Terampil Penyelia',
			'Arsiparis Ahli Pertama',
			'Arsiparis Ahli Muda',
			'Arsiparis Ahli Madya',
			'Arsiparis Ahli Utama',
			'Non Arsiparis'
		];

		$this->load->view('template/header', $data);
		$this->load->view('admin/chart_sdm', ['record' => $record, 'sub_data' => $sub_data, 'field' => $field]);
		$this->load->view('template/footer');
	}
	public function arsip()
	{
		$data['active'] = "active";
		$data['judul'] = "Data SDM Arsiparis";
		$this->load->model('Adminmodel');
		$this->load->view('template/header', $data);
		$records = $this->Adminmodel->dataarsip();
		$this->load->view('admin/arsip',['records'=>$records]);
		$this->load->view('template/footer');
	}
	public function detail_arsip()
	{
		$data['active'] = "active";
		$data['judul'] = "Data Arsip";

		$this->load->model('Adminmodel');
		$id_arsip = $this->uri->segment(3);
		$data_record = $this->Adminmodel->dataarsip($id_arsip)[0];
		$record = $this->clean_data($data_record, 'id_data_arsip');
		$sub_data = ['username' => $data_record->username, 'tahun' => $data_record->tahun];
		$field = [
			'Daftar Berkas Arsip Aktif',
			'Daftar Isi Berkas Arsip Aktif',
			'Data Arsip Aktif Media Kertas',
			'Data Arsip Aktif Media Foto',
			'Data Arsip Aktif Media Film',
			'Data Arsip Aktif Media Kartografi dan Kearsitekturan',
			'Daftar Berkas Arsip Vital',
			'Data Arsip Vital Media Kertas',
			'Data Arsip Vital Media Foto',
			'Data Arsip Vital Media Film',
			'Data Arsip Vital Media Kartografi dan Kearsitekturan',
			'Daftar Berkas Arsip Terjaga',
			'Data Arsip Terjaga Media Kertas',
			'Data Arsip Terjaga Media Foto',
			'Data Arsip Terjaga Media Film',
			'Data Arsip Terjaga Media Kartografi dan Kearsitekturan',
			'Daftar Berkas Arsip Inaktif',
			'Data Arsip Inaktif Media Kertas',
			'Data Arsip Inaktif Media Foto',
			'Data Arsip Inaktif Media Film',
			'Data Arsip Inaktif Media Kartografi dan Kearsitekturan',
			'Daftar Berkas Arsip Statis',
			'Inventaris Arsip Statis',
			'Data Arsip Statis Media Kertas',
			'Data Arsip Statis Media Foto',
			'Data Arsip Statis Media Film',
			'Data Arsip Statis Media Kartografi dan Kearsitekturan',
		];

		$this->load->view('template/header', $data);
		$this->load->view('admin/chart_arsip', ['record' => $record, 'sub_data' => $sub_data, 'field' => $field]);
		$this->load->view('template/footer');
	}
	public function anggaran()
	{
		$data['active'] = "active";
		$data['judul'] = "Data Anggaran";
		$this->load->model('Adminmodel');
		$this->load->view('template/header', $data);
		$records = $this->Adminmodel->dataanggaran();
		$this->load->view('admin/anggaran',['records'=>$records]);
		$this->load->view('template/footer');
	}
	public function detail_anggaran()
	{
		$data['active'] = "active";
		$data['judul'] = "Data Anggaran";

		$this->load->model('Adminmodel');
		$username = $this->uri->segment(3);
		$data_record = (array) $this->Adminmodel->dataanggaran($username);
		foreach (array_reverse($data_record) as $dr) {
			if ($dr->anggaran_lkd_kearsipan) {
				$record['kearsipan'][] = $dr->anggaran_lkd_kearsipan;
			}

			if ($dr->anggaran_lkd_perpustakaan) {
				$record['perpustakaan'][] = $dr->anggaran_lkd_perpustakaan;
			}
			$field[] = $dr->tahun;
		}
		$sub_data = ['username' => $data_record[0]->username];

		$this->load->view('template/header', $data);
		$this->load->view('admin/chart_anggaran', ['record' => $record, 'sub_data' => $sub_data, 'field' => $field]);
		$this->load->view('template/footer');
	}
	public function sistem()
	{
		$data['active'] = "active";
		$data['judul'] = "Data Sistem Pengolahan";
		$this->load->model('Adminmodel');
		$this->load->view('template/header', $data);
		$records = $this->Adminmodel->datasistem();
		$this->load->view('admin/sistem',['records'=>$records]);
		$this->load->view('template/footer');
	}
	public function gnsta()
	{
		$data['active'] = "active";
		$data['judul'] = "Data Gerakan Nasional Sadar Tertib Arsip";
		$this->load->model('Adminmodel');
		$this->load->view('template/header', $data);
		$records = $this->Adminmodel->datagnsta();
		$this->load->view('admin/gnsta',['records'=>$records]);
		$this->load->view('template/footer');
	}
	public function detail_gnsta()
	{
		$data['active'] = "active";
		$data['judul'] = "Data gnsta";

		$this->load->model('Adminmodel');
		$username = $this->uri->segment(3);
		$data_record = (array) $this->Adminmodel->datagnsta($username);
		foreach (array_reverse($data_record) as $dr) {
			$record[] = $dr->jml_gnsta;
			$field[] = $dr->gnsta_tgl;
		}
		$sub_data = ['username' => $data_record[0]->username];
		// echo "<pre>";
		// print_r($record);
		// print_r($field);
		// echo "</pre>";

		$this->load->view('template/header', $data);
		$this->load->view('admin/chart_gnsta', ['record' => $record, 'sub_data' => $sub_data, 'field' => $field]);
		$this->load->view('template/footer');
	}
	public function peraturan()
	{
		$data['active'] = "active";
		$data['judul'] = "Data Peraturan Kearsipan";
		$this->load->model('Adminmodel');
		$this->load->view('template/header', $data);
		$records = $this->Adminmodel->dataperaturan();
		$this->load->view('admin/peraturan',['records'=>$records]);
		$this->load->view('template/footer');
	}

	private function clean_data($plan_data, $primary_key)
	{
		if (is_object($plan_data)) {
			$data = (array) $plan_data;
		} else {
			$data = $plan_data;
		}

		unset($data[$primary_key]);
		unset($data['username']);
		unset($data['tahun']);
		return $data;
	}
}
