<?php 
defined('BASEPATH') OR die('No direct script access allowed!');

class User extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		if (!$this->session->userdata('status')) {
			redirect('login');
		} elseif ($this->session->userdata('status') !== 'user') {
			redirect('admin');
		}
	}

	public function logout () {
		$this->session->sess_destroy();
		redirect ('login');
	}
	public function daftar()
	{
	$this->load->model('Usermodel');
		$data1 = [
			'username' => $this->input->post('username'),
			'password' => md5($this->input->post('password')),
			'nama_lkd' => $this->input->post('nama_lkd'),
			'wilayah' => $this->input->post('wilayah'),
			'statuswilayah' => $this->input->post('statuswilayah'),
			'nomenklatur' => $this->input->post('nomenklatur'),
			'dasarhukum' => $this->input->post('dasarhukum'),
			'alamat' => $this->input->post('alamat'),
			'telp' => $this->input->post('telp'),
			'email' => $this->input->post('email'),
			'website' => $this->input->post('website'),
		];
		$result = $this->Usermodel->daftar($data1);
		if($result){
			echo "Berhasil";
			redirect(base_url('index.php/user/'));
		}else{
			echo "Gagal !";
		}
	}
	public function baru()
	{
		$this->load->view('user/daftar_lembaga');
	}
	public function index()
	{	
		$data['active'] = "active";
		$data['judul'] = "DATA LEMBAGA KEARSIPAN";
		$this->load->view('template_user/header',$data);
		$this->load->model('Usermodel');
		$data['kelembagaan'] = $this->Usermodel->profillembaga($this->session->userdata('username'));
		$this->load->view('user/kelembagaan', $data);
		$this->load->view('template_user/footer',$data);
	}
	public function update_kelembagaan()
	{
		$this->load->model('Usermodel');
		$data = [
			'nomenklatur' => $this->input->post('nomenklatur'),
			'nama_kepala' => $this->input->post('nama_kepala'),
			'alamat' => $this->input->post('alamat'),
			'telpfaks' => $this->input->post('telpfaks'),
			'email' => $this->input->post('email'),
			'website' => $this->input->post('website'),
		];

		$result = $this->Usermodel->update_kelembagaan($data, $this->session->userdata('username'));
		if($result){
			echo "Berhasil";
			redirect(base_url('index.php/user'));
		}else{
			echo "Gagal !";
		}
	}
	public function profil()
	{
		$data['active'] = "active";
		$data['judul'] = "DATA PENGELOLA APLIKASI";
		$this->load->view('template_user/header',$data);
		$this->load->model('Usermodel');
		$data['profil'] = $this->Usermodel->userlembaga($this->session->userdata('username'));
		$this->load->view('user/profil', $data);
		$this->load->view('template_user/footer',$data);
	}
	public function update_profil()
	{
		$this->load->model('Usermodel');
		$data = [
			'nama' => $this->input->post('nama'),
			'unit_kerja' => $this->input->post('unit_kerja'),
			'jabatan' => $this->input->post('jabatan'),
			'no_hp' => $this->input->post('no_hp'),
		];

		if ($this->input->post('password')) {
			$data['password'] = md5($this->input->post('password'));
		}

		$result = $this->Usermodel->updateprofil($data, $this->session->userdata('username'));
		if($result){
			echo "Berhasil";
			redirect(base_url('index.php/user/profil'));
		}else{
			echo "Gagal !";
		}
	}

	public function anggaran()
	{
		$data['active'] = "active";
		$data['judul'] = "DATA ANGGARAN";
		$this->load->view('template_user/header',$data);
		$this->load->model('Usermodel');
		$data['anggaran'] = $this->Usermodel->dataanggaran($this->session->userdata('username'));
		$this->load->view('user/anggaran', $data);
		$this->load->view('template_user/footer',$data);
	}

	public function tambah_anggaran()
	{
		$data['active'] = "active";
		$data['judul'] = "TAMBAH ANGGARAN";
		$this->load->view('template_user/header',$data);
		$this->load->view('user/tambah_anggaran');
		$this->load->view('template_user/footer',$data);
	}

	public function edit_anggaran()
	{
		$data['active'] = "active";
		$data['judul'] = "EDIT ANGGARAN";
		$this->load->view('template_user/header', $data);
		$this->load->model('Usermodel');
		$record = $this->Usermodel->dataanggaran(['id_anggaran', $this->uri->segment(3)]);
		$this->load->view('user/edit_anggaran', ['record' => $record]);
		$this->load->view('template_user/footer', $data);
	}

	public function aksi_tambah_anggran()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'anggaran_lkd_kearsipan' => $this->input->post('anggaran_lkd_kearsipan'),
			'anggaran_lkd_perpustakaan' => $this->input->post('anggaran_lkd_perpustakaan'),
			'tahun' => $this->input->post('tahun'),
		];

		$result = $this->Usermodel->tambahanggaran($data);
		if($result){
			echo "Berhasil";
			redirect(base_url('index.php/user/anggaran'));
		}else{
			echo "Gagal !";
		}
	}

	public function aksi_edit_anggran()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'anggaran_lkd_kearsipan' => $this->input->post('anggaran_lkd_kearsipan'),
			'anggaran_lkd_perpustakaan' => $this->input->post('anggaran_lkd_perpustakaan'),
			'tahun' => $this->input->post('tahun'),
		];

		$result = $this->Usermodel->editanggaran($data, $this->input->post('id_anggaran'));
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/anggaran'));
		} else {
			echo "Gagal !";
		}
	}

	public function hapus_anggaran()
	{
		$id_sarana = $this->uri->segment(3);
		$this->load->model('Usermodel');
		$result = $this->Usermodel->hapusanggaran($id_sarana);
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/anggaran'));
		} else {
			echo "Gagal !";
		}
	}
	public function sarpras()
	{
		$data['active'] = "active";
		$data['judul'] = "DATA SARANA PRASARANA";
		$this->load->view('template_user/header',$data);
		$this->load->model('Usermodel');
		$data['sarpras'] = $this->Usermodel->datasarpras($this->session->userdata('username'));
		$this->load->view('user/sarpras', $data);
		$this->load->view('template_user/footer',$data);
	}
	public function tambah_sarpras()
	{
		$data['active'] = "active";
		$data['judul'] = "TAMBAH SARANA DAN PRASARANA";
		$this->load->view('template_user/header',$data);
		$this->load->view('user/tambah_sarpras');
		$this->load->view('template_user/footer',$data);
	}
	public function edit_sarpras()
	{
		$data['active'] = "active";
		$data['judul'] = "EDIT SARANA DAN PRASARANA";
		$this->load->model('Usermodel');
		$record = $this->Usermodel->datasarpras(['id_sarpras', $this->uri->segment(3)]);
		$this->load->view('template_user/header', $data);
		$this->load->view('user/edit_sarpras', ['record' => $record]);
		$this->load->view('template_user/footer', $data);
	}
	public function aksi_tambah_sarpras()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'depo'=> $this->input->post('depo'),
			'record_center'=> $this->input->post('record_center'),
			'tahun'=> $this->input->post('tahun'),
		];
		$result = $this->Usermodel->tambahsarpras($data);
		if($result){
			echo "Berhasil";
			redirect(base_url('index.php/user/sarpras'));
		}else{
			echo "Gagal !";
		}
	}
	public function aksi_edit_sarpras()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'depo' => $this->input->post('depo'),
			'record_center' => $this->input->post('record_center'),
			'tahun' => $this->input->post('tahun'),
		];

		$result = $this->Usermodel->editsarpras($data, $this->input->post('id_sarpras'));
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/sarpras'));
		} else {
			echo "Gagal !";
		}
	}
	public function hapus_sarpras()
	{
		$id_sarana = $this->uri->segment(3);
		$this->load->model('Usermodel');
		$result = $this->Usermodel->hapussarpras($id_sarana);
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/sarpras'));
		} else {
			echo "Gagal !";
		}
	}
	public function sdm()
	{
		$data['active'] = "active";
		$data['judul'] = "DATA SDM ARSIPARIS";
		$this->load->view('template_user/header',$data);
		$this->load->model('Usermodel');
		$data['sdm'] = $this->Usermodel->datasdm($this->session->userdata('username'));
		$this->load->view('user/sdm', $data);
		$this->load->view('template_user/footer',$data);
	}
	public function tambah_sdm()
	{
		$data['active'] = "active";
		$data['judul'] = "TAMBAH SDM ARSIPARIS";
		$this->load->view('template_user/header',$data);
		$this->load->view('user/tambah_sdm');
		$this->load->view('template_user/footer',$data);
	}
	public function edit_sdm()
	{
		$data['active'] = "active";
		$data['judul'] = "EDIT SDM ARSIPARIS";
		$this->load->view('template_user/header', $data);
		$this->load->model('Usermodel');
		$record = $this->Usermodel->datasdm(['id_sdm', $this->uri->segment(3)]);
		$this->load->view('user/edit_sdm', ['record' => $record]);
		$this->load->view('template_user/footer', $data);
	}
	public function aksi_tambah_sdm()
	{
	$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'arsiparis_terampil' => $this->input->post('arsiparis_terampil'),
			'arsiparis_mahir'=> $this->input->post('arsiparis_mahir'),
			'arsiparis_penyelia'=> $this->input->post('arsiparis_penyelia'),
			'arsiparis_pertama'=> $this->input->post('arsiparis_pertama'),
			'arsiparis_muda'=> $this->input->post('arsiparis_muda'),
			'arsiparis_madya'=> $this->input->post('arsiparis_madya'),
			'tenaga_non_arsiparis'=> $this->input->post('tenaga_non_arsiparis'),
			'tahun'=> $this->input->post('tahun'),
		];
		$result = $this->Usermodel->tambahsdm($data);
		if($result){
			echo "Berhasil";
			redirect(base_url('index.php/user/sdm'));
		}else{
			echo "Gagal !";
		}
	}
	public function aksi_edit_sdm()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'arsiparis_terampil' => $this->input->post('arsiparis_terampil'),
			'arsiparis_mahir'=> $this->input->post('arsiparis_mahir'),
			'arsiparis_penyelia'=> $this->input->post('arsiparis_penyelia'),
			'arsiparis_pertama'=> $this->input->post('arsiparis_pertama'),
			'arsiparis_muda'=> $this->input->post('arsiparis_muda'),
			'arsiparis_madya'=> $this->input->post('arsiparis_madya'),
			'tenaga_non_arsiparis'=> $this->input->post('tenaga_non_arsiparis'),
			'tahun'=> $this->input->post('tahun'),
		];
		$result = $this->Usermodel->editsdm($data, $this->input->post('id_sdm'));
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/sdm'));
		} else {
			echo "Gagal !";
		}
	}
	public function hapus_sdm()
	{
		$id_sdm = $this->uri->segment(3);
		$this->load->model('Usermodel');
		$result = $this->Usermodel->hapussdm($id_sdm);
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/sdm'));
		} else {
			echo "Gagal !";
		}
	}
	public function arsip()
	{
		$data['active'] = "active";
		$data['judul'] = "DATA KHASANAH ARSIP";
		$this->load->view('template_user/header',$data);
		$this->load->model('Usermodel');
		$data['arsip'] = $this->Usermodel->dataarsip($this->session->userdata('username'));
		$this->load->view('user/arsip', $data);
		$this->load->view('template_user/footer',$data);
	}
	public function tambah_arsip()
	{
		$data['active'] = "active";
		$data['judul'] = "TAMBAH DATA ARSIP";
		$this->load->view('template_user/header', $data);
		$this->load->view('user/tambah_arsip');
		$this->load->view('template_user/footer', $data);
	}
	public function edit_arsip()
	{
		$data['active'] = "active";
		$data['judul'] = "EDIT DATA ARSIP";
		$this->load->view('template_user/header', $data);
		$this->load->model('Usermodel');
		$record = $this->Usermodel->dataarsip(['id_khasanah', $this->uri->segment(3)]);
		$this->load->view('user/edit_arsip', ['record' => $record]);
		$this->load->view('template_user/footer', $data);
	}
	public function aksi_tambah_arsip()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'tahun' => $this->input->post('tahun'),
			'arsip_inaktif' => $this->input->post('arsip_inaktif'),
			'ai_kertas' => $this->input->post('ai_kertas'),
			'ai_foto' => $this->input->post('ai_foto'),
			'ai_film' => $this->input->post('ai_film'),
			'ai_kartografidankearsitekturan' => $this->input->post('ai_kartografidankearsitekturan'),
			'arsip_statis' => $this->input->post('arsip_statis'),
			'as_kertas' => $this->input->post('as_kertas'),
			'as_foto' => $this->input->post('as_foto'),
			'as_film' => $this->input->post('as_film'),
			'as_kartografidankearsitekturan' => $this->input->post('as_kartografidankearsitekturan'),
		];
		$result = $this->Usermodel->tambaharsip($data);
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/arsip'));
		} else {
			echo "Gagal !";
		}
	}
	public function aksi_edit_arsip()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'tahun' => $this->input->post('tahun'),
			'arsip_inaktif' => $this->input->post('arsip_inaktif'),
			'ai_kertas' => $this->input->post('ai_kertas'),
			'ai_foto' => $this->input->post('ai_foto'),
			'ai_film' => $this->input->post('ai_film'),
			'ai_kartografidankearsitekturan' => $this->input->post('ai_kartografidankearsitekturan'),
			'arsip_statis' => $this->input->post('arsip_statis'),
			'as_kertas' => $this->input->post('as_kertas'),
			'as_foto' => $this->input->post('as_foto'),
			'as_film' => $this->input->post('as_film'),
			'as_kartografidankearsitekturan' => $this->input->post('as_kartografidankearsitekturan'),
		];
		$result = $this->Usermodel->editarsip($data, $this->input->post('id_khasanah'));
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/arsip'));
		} else {
			echo "Gagal !";
		}
	}
	public function hapus_arsip()
	{
		$id_sarana = $this->uri->segment(3);
		$this->load->model('Usermodel');
		$result = $this->Usermodel->hapusarsip($id_sarana);
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/arsip'));
		} else {
			echo "Gagal !";
		}
	}
	public function sistem()
	{
		$data['active'] = "active";
		$data['judul'] = "SISTEM PENGOLAHAN ARSIP";
		$this->load->view('template_user/header',$data);
		$this->load->model('Usermodel');
		$data['sistem'] = $this->Usermodel->datasistem($this->session->userdata('username'));
		$this->load->view('user/sistem_kearsipan', $data);
		$this->load->view('template_user/footer',$data);
	}
	public function gnsta()
	{
		$data['active'] = "active";
		$data['judul'] = "KEGIATAN GERAKAN NASIONAL SADAR TERTIB ARSIP";
		$this->load->view('template_user/header',$data);
		$this->load->model('Usermodel');
		$data['gnsta'] = $this->Usermodel->datagnsta($this->session->userdata('username'));
		$this->load->view('user/gnsta', $data);
		$this->load->view('template_user/footer',$data);
	}
	public function tambah_gnsta()
	{
		$data['active'] = "active";
		$data['judul'] = "TAMBAH KEGIATAN GERAKAN NASIONAL SADAR TERTIB ARSIP";
		$this->load->view('template_user/header',$data);
		$this->load->view('user/tambah_gnsta');
		$this->load->view('template_user/footer',$data);
	}
	public function edit_gnsta()
	{
		$data['active'] = "active";
		$data['judul'] = "EDIT KEGIATAN GERAKAN NASIONAL SADAR TERTIB ARSIP";
		$this->load->view('template_user/header', $data);
		$this->load->model('Usermodel');
		$record = $this->Usermodel->datagnsta(['id_gnsta', $this->uri->segment(3)]);
		$this->load->view('user/edit_gnsta', ['record' => $record]);
		$this->load->view('template_user/footer', $data);
	}
	public function aksi_tambah_gnsta()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'gnsta_uraian' => $this->input->post('gnsta_uraian'),
			'gnsta_tgl' => $this->input->post('gnsta_tgl'),
		];
		$result = $this->Usermodel->tambahgnsta($data);
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/gnsta'));
		} else {
			echo "Gagal !";
		}
	}
	public function aksi_edit_gnsta()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'gnsta_uraian' => $this->input->post('gnsta_uraian'),
			'gnsta_tgl' => $this->input->post('gnsta_tgl'),
		];
		$result = $this->Usermodel->editgnsta($data, $this->input->post('id_gnsta'));
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/gnsta'));
		} else {
			echo "Gagal !";
		}
	}
	public function hapus_gnsta()
	{
		$id_sarana = $this->uri->segment(3);
		$this->load->model('Usermodel');
		$result = $this->Usermodel->hapusgnsta($id_sarana);
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/gnsta'));
		} else {
			echo "Gagal !";
		}
	}
	
	public function aksi_sistem_informasi()
	{
		
		$data = [
			'username' => $this->session->userdata('username'),
			'sikd_terima' => $this->input->post('sikd_terima'),
			'sikd_tanggal' => $this->input->post('sikd_tanggal'),
			'siks_terima' => $this->input->post('siks_terima'),
			'siks_tanggal' => $this->input->post('siks_tanggal'),
			'sikn_jikn' => $this->input->post('sikn_jikn'),
			'sikn_jikn_tanggal' => $this->input->post('sikn_jikn_tanggal'),
			'sistem_informasi_lain' => $this->input->post('sistem_informasi_lain'),
			'sistem_informasi_lain_tanggal' => $this->input->post('sistem_informasi_lain_tanggal'),
		];
		$this->load->model('Usermodel');
		$check = $this->Usermodel->datasistem($this->session->userdata('username'));
		if ($check) {
			// update bila sudah ada data
			$result = $this->Usermodel->editsistem($data, $this->session->userdata('username'));
		} else {
			// insert bila belum ada data
			$result = $this->Usermodel->tambahsistem($data);
		}
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/sistem'));
		} else {
			echo "Gagal !";
		}
	}
	public function peraturan()
	{
		$data['active'] = "active";
		$data['judul'] = "PERATURAN KEARSIPAN";
		$this->load->view('template_user/header',$data);
		$this->load->model('Usermodel');
		$data['profil'] = $this->Usermodel->dataperaturan($this->session->userdata('username'));
		$this->load->view('user/peraturan', $data);
		$this->load->view('template_user/footer',$data);
	}
	public function aksi_peraturan()
	{
		$data = [
			'username' => $this->session->userdata('username'),
			'peraturan_daerah' => $this->input->post('peraturan_daerah'),
			'peraturan_kepala' => $this->input->post('peraturan_kepala'),
			'edaran' => $this->input->post('edaran'),
			'tnd' => $this->input->post('tnd'),
			'jra' => $this->input->post('jra'),
			'klasifikasi' => $this->input->post('klasifikasi'),
			'kka' => $this->input->post('kka'),
			'pedoman_pengolahaan_arsip' => $this->input->post('pedoman_pengolahaan_arsip'),
		];
		$this->load->model('Usermodel');
		$check = $this->Usermodel->dataperaturan($this->session->userdata('username'));
		if ($check) {
			// update bila sudah ada data
			$result = $this->Usermodel->editperaturan($data, $this->session->userdata('username'));
		} else {
			// insert bila belum ada data
			$result = $this->Usermodel->tambahperaturan($data);
		}
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/peraturan'));
		} else {
			echo "Gagal !";
		}
	}
/*	public function editperaturan()
	{
		$this->load->model('Usermodel');
		$data = [
			'username' => $this->session->userdata('username'),
			'pk_daerah' => $this->input->post('pk_daerah'),
			'pk_kepala_daerah' => $this->input->post('pk_kepala_daerah'),
			'pk_edaran' => $this->input->post('pk_edaran'),
			'pk_tnd' => $this->input->post('pk_tnd'),
			'pk_klasifikasi' => $this->input->post('pk_klasifikasi'),
			'pk_jra' => $this->input->post('pk_jra'),
			'pk_kka' => $this->input->post('pk_kka'),
		];
		$result = $this->Usermodel->editperaturan($data, $this->input->post('id_peraturan'));
		if ($result) {
			echo "Berhasil";
			redirect(base_url('index.php/user/peraturan'));
		} else {
			echo "Gagal !";
		}
	}*/

	
}
