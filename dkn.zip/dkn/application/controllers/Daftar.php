<?php
defined('BASEPATH') OR die('No direct script access allowed!');

/**
* 
*/
class Daftar extends CI_Controller
{
	public function index()
	{
		$this->load->view('user/daftar_lembaga');
	}
}
?>