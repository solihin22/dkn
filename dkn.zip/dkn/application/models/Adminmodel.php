<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Adminmodel extends CI_Model
{
    public function cek_login($table,$where){       
        return $this->db->get_where($table,$where);
    }
    public function datalembaga($username = '') 
    {
        if ($username !== '') {
            $this->db->where('username', $username);
        }
       return $this->db->get('kelembagaan')->result();
    }
    public function pengelolalembaga($username='')
    {
        if ($username !== '') {
            $this->db->where('username', $username);
        }
        $this->db->select('user.*, kelembagaan.username AS username, kelembagaan.*');
        $this->db->join('kelembagaan', 'user.username = kelembagaan.username');
        $this->db->from('user');
        $query = $this->db->get();
      return $query->result();
    }
    public function datasarpras($id_sarpras = '')
    {
        if ($id_sarpras !== '') {
            $this->db->where('id_sarpras', $id_sarpras);
        }
       return $this->db->get('saranaprasarana')->result();
    }
    public function datasdm($id_sdm = '')
    {
        if ($id_sdm !== '') {
            $this->db->where('id_sdm', $id_sdm);
        }
       return $this->db->get('sdm')->result();
    }
    public function dataarsip($id_khasanah = '')
    {
        if ($id_khasanah !== '') {
            $this->db->where('id_khasanah', $id_khasanah);
        }
        return $this->db->get('khasanah')->result();
    }
    public function dataanggaran($username = '')
    {
        if ($username !== '') {
            $this->db->where('username', $username);
            $this->db->order_by('tahun', 'DESC');
            $this->db->group_by('tahun');
            $this->db->limit(5, 0);
        }
       return $this->db->get('anggaran')->result();  
    }
    public function datasistem()
    {
       return $this->db->get('sistem_informasi_pengolahan')->result();  
    }
    public function datagnsta($username = '')
    {
        if ($username !== '') {
            $this->db->select('*, COUNT(id_gnsta) AS jml_gnsta');
            $this->db->where('username', $username);
            $this->db->order_by('gnsta_tgl', 'DESC');
            $this->db->group_by('gnsta_tgl');
            $this->db->limit(5, 0);
        }
       return $this->db->get('gnsta')->result();  
    }
    public function dataperaturan()
    {
       return $this->db->get('pedoman_pengelolaan')->result();  
    }
//    private $_table = "lembaga";

/*    public $username;
    public $password;
    public $nama_lkd;
    public $wilayah;
    public $statuswilayah;
    public $nomenklatur;
    public $dasarhukum;
    public $alamat;
    public $telp;
    public $email;
    public $website;
//    public $;

    public function rules()
    {
        return [
            ['field' => 'username',
            'label' => 'Username',
            'rules' => 'required'],

            ['field' => 'password',
            'label' => 'Password',
            'rules' => 'required'],

            ['field' => 'nama_lkd',
            'label' => 'Nama_lkd',
            'rules' => 'required'],

            ['field' => 'wilayah',
            'label' => 'Wilayah',
            'rules' => 'required'],

            ['field' => 'statuswilayah',
            'label' => 'Statuswilayah',
            'rules' => 'required'],

            ['field' => 'nomenklatur',
            'label' => 'Nomenklatur',
            'rules' => 'required'],

            ['field' => 'dasarhukum',
            'label' => 'Dasarhukum',
            'rules' => 'required'],

            ['field' => 'alamat',
            'label' => 'Alamat',
            'rules' => 'required'],

            ['field' => 'telp',
            'label' => 'Telp',
            'rules' => 'required'],

            ['field' => 'email',
            'label' => 'Email',
            'rules' => 'required'],

            ['field' => 'website',
            'label' => 'Website',
            'rules' => 'required'],
        ];
    }
*/
   
    

    /*
    public function simpan_profile()
    {
        $post = $this->input->post();
        $this->username = $post["username"];
        $this->password = $post["password"];
        $this->nama_lkd = $post["nama_lkd"];
        $this->wilayah = $post["wilayah"];
        $this->statuswilayah = $post["statuswilayah"];
        $this->nomenklatur = $post["nomenklatur"];
        $this->dasarhukum = $post["dasarhukum"];
        $this->alamat = $post["alamat"];
        $this->telp = $post["telp"];
        $this->email = $post["email"];
        $this->website = $post["website"];
        $this->description = $post["description"];
        $this->db->insert($this->_table, $this);
    }
/*
    public function update()
    {
        $post = $this->input->post();
        $this->product_id = $post["username"];
        $this->name = $post["name"];
        $this->price = $post["price"];
        $this->description = $post["description"];
        $this->db->update($this->_table, $this, array('product_id' => $post['id']));
    }

    public function delete_lembaga($username)
    {
        return $this->db->delete($this->_table, array("username" => $username));
    }
*/
}