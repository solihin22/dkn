<?php
defined('BASEPATH') OR die('No direct script access allowed!');
/**
* 
*/
class Usermodel extends CI_Model
{
	public function cek_login($table, $where)
	{
		return $this->db->get_where($table,$where);
	}
	public function userbaru($data1)
	{
		return $this->db->insert('user', $data1);
	}
	public function kelembagaan($data2)
	{
		return $this->db->insert('kelembagaan', $data2);
	}
	public function userlembaga($username)
	{
		$this->db->where('username', $username);
		return $this->db->get('user')->result();
	}
	public function profillembaga($username)
	{
		$this->db->where('username', $username);
		return $this->db->get('kelembagaan')->result();
	}
	public function updateprofil($data, $username)
	{
		$this->db->where('username', $username);
		return $this->db->update('user', $data);
	}
	public function updatekelembagaan($data, $username)
	{
		$this->db->where('username', $username);
		return $this->db->update('kelembagaan', $data);
	}
	public function dataanggaran($username)
	{
		if (is_array($username)) {
			$this->db->where($username[0], $username[1]);
		} else {
			$this->db->where('username', $username);
		}
		return $this->db->get('anggaran')->result();
	}

	public function tambahanggaran($data)
	{
		return $this->db->insert('anggaran', $data);
	}
	public function editanggaran($data, $id_anggaran)
	{
		$this->db->where('id_anggaran', $id_anggaran);
		return $this->db->update('anggaran', $data);
	}
	public function hapusanggaran($id_anggaran)
	{
		$this->db->where('id_anggaran', $id_anggaran);
		return $this->db->delete('anggaran');
	}
	public function datasarpras($username)
	{
		if (is_array($username)) {
			$this->db->where($username[0], $username[1]);
		} else {
			$this->db->where('username', $username);
		}
		return $this->db->get('saranaprasarana')->result();
	}
	public function tambahsarpras($data)
	{
		return $this->db->insert('saranaprasarana', $data);
	}
	public function editsarpras($data, $id_sarpras)
	{
		$this->db->where('id_sarpras', $id_sarpras);
		return $this->db->update('saranaprasarana', $data);
	}
	public function hapussarpras($id_sarpras)
	{
		$this->db->where('id_sarpras', $id_sarpras);
		return $this->db->delete('saranaprasarana');
	}
	public function datasdm($username)
	{
		if (is_array($username)) {
			$this->db->where($username[0], $username[1]);
		} else {
			$this->db->where('username', $username);
		}
		return $this->db->get('sdm')->result();
	}
	public function tambahsdm($data)
	{
		return $this->db->insert('sdm', $data);
	}
	public function editsdm($data, $id_sdm)
	{
		$this->db->where('id_sdm', $id_sdm);
		return $this->db->update('sdm', $data);
	}
	public function hapussdm($id_sdm)
	{
		$this->db->where('id_sdm', $id_sdm);
		return $this->db->delete('sdm');
	}
	public function dataarsip($username)
	{
		if (is_array($username)) {
			$this->db->where($username[0], $username[1]);
		} else {
			$this->db->where('username', $username);
		}
		return $this->db->get('khasanah')->result();
	}
	public function tambaharsip($data)
	{
		return $this->db->insert('khasanah', $data);
	}
	public function editarsip($data, $id_khasanah)
	{
		$this->db->where('id_khasanah', $id_khasanah);
		return $this->db->update('khasanah', $data);
	}
	public function hapusarsip($id_khasanah)
	{
		$this->db->where('id_khasanah', $id_khasanah);
		return $this->db->delete('khasanah');
	}

	public function datagnsta($username)
	{
		if (is_array($username)) {
			$this->db->where($username[0], $username[1]);
		} else {
			$this->db->where('username', $username);
		}
		return $this->db->get('gnsta')->result();
	}
	public function tambahgnsta($data)
	{
		return $this->db->insert('gnsta', $data);
	}
	public function editgnsta($data, $id_gnsta)
	{
		$this->db->where('id_gnsta', $id_gnsta);
		return $this->db->update('gnsta', $data);
	}
	public function hapusgnsta($id_gnsta)
	{
		$this->db->where('id_gnsta', $id_gnsta);
		return $this->db->delete('gnsta');
	}
	public function datasistem($username)
	{
		$this->db->where('username', $username);
		return $this->db->get('sistem_informasi_pengolahan')->result();
	}
	public function tambahsistem($data)
	{
		return $this->db->insert('sistem_informasi_pengolahan', $data);
	}
	public function editsistem($data, $username)
	{
		$this->db->where('username', $username);
		return $this->db->update('sistem_informasi_pengolahan', $data);
	}

	public function dataperaturan($username)
	{
		$this->db->where('username', $username);
		return $this->db->get('pedoman_pengelolaan')->result();
	}
	public function tambahperaturan($data)
	{
		return $this->db->insert('pedoman_pengelolaan', $data);
	}
	public function editperaturan($data, $username)
	{
		$this->db->where('username', $username);
		return $this->db->update('pedoman_pengelolaan', $data);
	}
}
