<?php
defined('BASEPATH') OR die('No direct script access allowed!');

class Chart_Model extends CI_Model
{
    public function all_data_sarpras($year)
    {
        $this->db->where('tahun', $year);
        $data = $this->db->get('sarana_prasarana')->result();
        return $data;
    }

    public function all_data_sdm($year)
    {
        $this->db->where('tahun', $year);
        $data = $this->db->get('sdm')->result();
        return $data;
    }

    public function all_data_arsip($year)
    {
        $this->db->where('tahun', $year);
        $data = $this->db->get('arsip')->result();
        return $data;
    }

    public function all_data_anggaran($year)
    {
        $this->db->where('tahun', $year);
        $data = $this->db->get('anggaran')->result();
        return $data;
    }

    public function all_data_gnsta($year)
    {
        $this->db->select('COUNT(`id_gnsta`), `username`');
        $this->db->where('gnsta_tgl', $year);
        $this->db->group_by('username');
        $data = $this->db->get('gnsta')->result();
        return $data;
    }
}

