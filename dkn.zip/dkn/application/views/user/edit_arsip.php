			<div class="page-inner">
			    <div class="page-header">
			        <h4 class="page-title"><?php echo $judul; ?></h4>
			    </div>
			    <?php echo form_open('user/aksi_edit_arsip'); ?>
			    <?php foreach ($record as $r) : ?>
			        <div class="row">
			            <div class="col-md-12">
			                <div class="card">
			                    <div class="card-body">
			                        
			                        <div class="row">
			                            <div class="col-md-12 col-lg-6">
			                            <div class="form-group">
			                                <h3 class="text-uppercase mb-3">Data Arsip Statis</h3>
			                                <label for="text">Jumlah Arsip Statis</label>
			                                <?php echo form_input('arsip_statis', $r->arsip_statis, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Kertas</label>
			                                 <?php echo form_input('as_kertas', $r->as_kertas, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Foto</label>
			                                 <?php echo form_input('as_foto', $r->as_foto, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Film</label>
			                                 <?php echo form_input('as_film', $r->as_film, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Kartografi dan Kearsitekturan</label>
			                                  <?php echo form_input('as_kartografidankearsitekturan', $r->as_kartografidankearsitekturan, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                        </div>
			                        <div class="col-md-12 col-lg-6">
			                            <div class="form-group">
			                                <h3 class="text-uppercase mb-3">Data Arsip Inaktif</h3>
			                                <label for="text">Jumlah Arsip Inaktif</label>
			                                <?php echo form_input('arsip_inaktif', $r->arsip_inaktif, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Kertas</label>
			                                 <?php echo form_input('ai_kertas', $r->ai_kertas, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Foto</label>
			                                 <?php echo form_input('ai_foto', $r->ai_foto, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Film</label>
			                                 <?php echo form_input('ai_film', $r->ai_film, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Kartografi dan Kearsitekturan</label>
			                                  <?php echo form_input('ai_kartografidankearsitekturan', $r->ai_kartografidankearsitekturan, 'placeholder="2018" class="form-control"'); ?>
			                            </div>
			                        </div>

			                        </div>
			                        <div class="form-group">
			                            <label for="">TAHUN</label>
                                        <?php echo form_input('tahun', $r->tahun, 'placeholder="2018" class="form-control"'); ?>
                                        <input type="hidden" name="id_khasanah" value="<?= $r->id_khasanah ?>">
			                        </div>
			                    </div>
			                    <div class="card-action">
 								<div class="form-group">
			                    <?php echo form_submit('submit', 'UPDATE', 'class="btn btn-primary"'); ?>
			                    <?php echo form_close(); ?>
			                    </div>
			                </div>
			            </div>
			        </div>
			    <?php endforeach; ?>
			</div>