<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"><?php echo $judul;?></h4>
					</div>
					<?php echo form_open('user/update_kelembagaan'); ?>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<?php foreach ($kelembagaan as $p): ?>

										<div class="form-group">
											<label for="">Nomenklatur</label>
											<?php echo form_input('nomenklatur', $p->nomenklatur, 'placeholder="Silahkan Isi Nomenklatur Anda" class="form-control"'); ?>
										</div>
										<div class="form-group">
											<label for="">Nama Kepala Lembaga Kearsipan</label>
											<?php echo form_input('nama_kepala', $p->nama_kepala, 'placeholder="Silahkan Isi Dasar Hukum Anda" class="form-control"'); ?>
										</div>
										<div class="form-group">
											<label for="">Alamat</label>
											<?php echo form_input('alamat', $p->alamat, 'placeholder="Silahkan Isi Alamat Anda" class="form-control"'); ?>
										</div>
										<div class="form-group">
											<label for="">Telp</label>
											<?php echo form_input('telpfaks', $p->telpfaks, 'placeholder="Silahkan Isi Telp Anda" class="form-control"'); ?>
										</div>
										<div class="form-group">
											<label for="">Email</label>
											<?php echo form_input('email', $p->email, 'placeholder="Silahkan Isi Email Anda" class="form-control"'); ?>
										</div>
										<div class="form-group">
											<label for="">Website</label>
											<?php echo form_input('website', $p->website, 'placeholder="Silahkan Isi Website Anda" class="form-control"'); ?>
										</div>
										
										<?php endforeach ?>
										<div class="form-group">
											<?php echo form_submit('submit', 'EDIT', 'class="btn btn-primary"'); ?>
											<?php echo form_close(); ?>
										</div>
								</div>
							</div>
						</div>
					</div>
				</div>