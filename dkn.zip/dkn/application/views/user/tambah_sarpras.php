			<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"><?php echo $judul;?></h4>
					</div>
					<?php echo form_open('user/aksi_tambah_sarpras'); ?>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="form-group">
										<label for="">Depo Arsip</label>
										<?php echo form_input('depo','', 'placeholder="Jumlah Depo Arsip" class="form-control"'); ?>
									</div>
									<div class="form-group">
										<label for="">Record Center</label>
										<?php echo form_input('record_center','', 'placeholder="Jumlah Record Center" class="form-control"'); ?>
									</div>
									<div class="form-group">
										<label for="">TAHUN</label>
										<?php echo form_input('tahun','', 'placeholder="2018" class="form-control"'); ?>
									</div>

								</div>
								<div class="card-action">
										<?php echo form_submit('submit', 'Simpan', 'class="btn btn-primary"'); ?>
										<?php echo form_close(); ?>
								</div>
							</div>
						</div>
					</div>
				</div>