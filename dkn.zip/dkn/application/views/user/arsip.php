<div class="page-inner">
	<div class="page-header">
		<h4 class="page-title"><?php echo $judul; ?></h4>
	</div>
	<p>
		<a href="<?= base_url('user/tambah_arsip') ?>" class="btn btn-primary">Tambah Data Arsip</a>
	</p>
	<div class="row">
		<div class="col-md-12">
			<div class="card">

				<div class="card-body">
					<div class="table-responsive">
						<table id="basic-datatables" class="display table table-striped table-hover">
							<thead>
								<tr>
									<th>Arsip Statis</th>
									<th>Arsip Kertas(as)</th>
									<th>Arsip Foto(as)</th>
									<th>Arsip Film(as)</th>
									<th>Arsip Katografi(as)</th>
									<th>Daftar Inaktif</th>
									<th>Arsip Kertas(ai)</th>
									<th>Arsip Foto(ai)</th>
									<th>Arsip Film(ai)</th>
									<th>Arsip Katografi(ai)</th>									
									<th>Tahun</th>
									<th>Aksi</th>
								</tr>
							</thead>

							<tbody>
								<?php foreach ($arsip as $record) { ?>
									<tr>
										<td><?php echo $record->arsip_statis; ?></td>
										<td><?php echo $record->as_kertas; ?></td>
										<td><?php echo $record->as_foto; ?></td>
										<td><?php echo $record->as_film; ?></td>
										<td><?php echo $record->as_kartografidankearsitekturan; ?></td>
										<td><?php echo $record->arsip_inaktif; ?></td>
										<td><?php echo $record->ai_kertas; ?></td>
										<td><?php echo $record->ai_foto; ?></td>
										<td><?php echo $record->ai_film; ?></td>
										<td><?php echo $record->ai_kartografidankearsitekturan; ?></td>
										<td><?php echo $record->tahun; ?></td>
										<td>
											<a href="<?= base_url('user/edit_arsip/' . $record->id_khasanah) ?>" class="btn btn-xs btn-primary"><i class="fa fa-pen"></i></a>
											<a href="<?= base_url('user/hapus_arsip/' . $record->id_khasanah) ?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
						<p>*aa (arsip aktif) - av (arsip vital) - at (arsip terjaga) - ai (arsip inaktif) - as (arsip statis)</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>