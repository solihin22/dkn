<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>PENDAFTARAN</title>
  
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/reset.min.css">

  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900|Material+Icons'>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/daftar.css">
</head>
<body>
<div class="container">
<!-- Form-->
<!--      <h1 align="center"><img src="<?php echo base_url();?>assets/img/logo_anri.jpg" width="350"></h1>-->
    <h3 align="center">PENDAFTARAN LEMBAGA KEARSIPAN</h3>
      <?php if (@$this->session->flashdata('error')) : ?>
      <div class="alert alert-danger" role="alert">
        <?= $this->session->flashdata('error') ?>
      </div>
    <?php endif; ?>

      <?php echo form_open('login/daftar_baru'); ?>
        <div class="row">
          <div class="col-md-12">
            <div class="row">
                  <div class="col-md-6 col-lg-6">
                   <div class="form-group">
                      <label for="username">Username</label>
                      <input type="text" name="username" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="password">Password</label>
                      <input type="password" id="password" name="password" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="username">Nama Lengkap</label>
                      <input type="text" name="nama" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="username">Jabatan</label>
                      <input type="text" name="jabatan" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="username">No. HP</label>
                      <input type="text" name="no_hp" required="required" class="form-control"/>
                    </div>
                    
                    <div class="form-group" >
                      <label for="username">Status</label>
                      <select name="status" class="form-control">
                        <option value="1">Provinsi</option>
                        <option value="2">Kabupaten/Kota</option>
                        <!--<option value="3">KL</option>
                        <option value="4">Perguruan Tinggi</option>-->
                      </select>
                    </div>
                     <div class="form-group">
                      <button type="submit" class="btn btn-primary">DAFTAR</button>
                      <?php echo form_close(); ?>
                      <a href="<?php echo base_url();?>"><button type="button" class="btn btn-danger">KEMBALI</button></a>
                      <?php echo form_close(); ?>
                    </div>
                    </div>
                    <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                      <label for="text">Nomen Kelatur</label>
                      <input type="text" id="nomenklatur" name="nomenklatur" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Nama Kepala LKD</label>
                      <input type="text" id="nama_kepala" name="nama_kepala" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Alamat</label>
                      <textarea name="alamat" class="form-control" rows="1"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="text">Telp/Faks</label>
                      <input type="text" id="telpfaks" name="telpfaks" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Email</label>
                      <input type="text" id="email" name="email" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Website</label>
                      <input type="text" id="website" name="website" required="required" class="form-control"/>
                    </div>
                    
                </div>
                <div class="col-md-12">
                   
                </div>
              </div>
          </div>
      </form>
    </div>
</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://codepen.io/andytran/pen/vLmRVp.js'></script>
    <script  src="<?php echo base_url();?>assets/js/index.js"></script>
</body>
</html>