<div class="page-inner">
	<div class="page-header">
		<h4 class="page-title"><?php echo $judul; ?></h4>
	</div>
	<?php echo form_open('user/aksi_peraturan'); ?>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body"> 
					<?php if ($profil) : ?>
						<?php foreach ($profil as $p) : ?>
							<div class="form-group">
								<label for="">Peraturan Kearsipan Daerah</label>
								<?php echo form_textarea('peraturan_daerah', $p->peraturan_daerah, 'placeholder="Peraturan Kearsipan Daerah" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Peraturan Kearsipan Gubernur/Bupati/Walikota</label>
								<?php echo form_textarea('peraturan_kepala', $p->peraturan_kepala, 'placeholder="Peraturan Kearsipan Gubernur/Bupati/Walikota" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Surat Edaran / Instruksi Gubernur / Instruksi Bupati/Walikota </label>
								<?php echo form_textarea('edaran', $p->edaran, 'placeholder="Surat Edaran / Instruksi Gubernur/Instruksi Bupati/Walikota " class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Pedoman Tata Naskah Dinas</label>
								<?php echo form_textarea('tnd', $p->tnd, 'placeholder="Pedoman Tata Naskah Dinas" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Pedoman Tata Naskah Dinas</label>
								<?php echo form_textarea('jra', $p->jra, 'placeholder="Pedoman Tata Naskah Dinas" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Klasifikasi Arsip</label>
								<?php echo form_textarea('klasifikasi', $p->klasifikasi, 'placeholder="Klasifikasi Arsip" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Klasifikasi Keamanan dan Akses</label>
								<?php echo form_textarea('kka', $p->kka, 'placeholder="Klasifikasi Keamanan dan Akses" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Klasifikasi Keamanan dan Akses</label>
								<?php echo form_textarea('pedoman_pengolahaan_arsip', $p->pedoman_pengolahaan_arsip, 'placeholder="Klasifikasi Keamanan dan Akses" class="form-control"'); ?>
							</div>
						<?php endforeach ?>
					<?php else : ?>
						<div class="form-group">
								<label for="">Peraturan Kearsipan Daerah</label>
								<?php echo form_textarea('peraturan_daerah', '', 'placeholder="Peraturan Kearsipan Daerah" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Peraturan Kearsipan Gubernur/Bupati/Walikota</label>
								<?php echo form_textarea('peraturan_kepala', '', 'placeholder="Peraturan Kearsipan Gubernur/Bupati/Walikota" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Surat Edaran / Instruksi Gubernur / Instruksi Bupati/Walikota </label>
								<?php echo form_textarea('edaran', '', 'placeholder="Surat Edaran / Instruksi Gubernur/Instruksi Bupati/Walikota " class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Pedoman Tata Naskah Dinas</label>
								<?php echo form_textarea('tnd', '', 'placeholder="Pedoman Tata Naskah Dinas" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Pedoman Tata Naskah Dinas</label>
								<?php echo form_textarea('jra', '', 'placeholder="Pedoman Tata Naskah Dinas" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Klasifikasi Arsip</label>
								<?php echo form_textarea('klasifikasi','', 'placeholder="Klasifikasi Arsip" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Klasifikasi Keamanan dan Akses</label>
								<?php echo form_textarea('kka', '', 'placeholder="Klasifikasi Keamanan dan Akses" class="form-control"'); ?>
							</div>
							<div class="form-group">
								<label for="">Klasifikasi Keamanan dan Akses</label>
								<?php echo form_textarea('pedoman_pengolahaan_arsip','', 'placeholder="Klasifikasi Keamanan dan Akses" class="form-control"'); ?>
							</div>
					<?php endif; ?>
					<div class="form-group">
						<?php echo form_submit('submit', 'UPDATE', 'class="btn btn-primary"'); ?>
						<?php echo form_close(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
