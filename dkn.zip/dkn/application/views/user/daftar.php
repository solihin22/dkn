<!DOCTYPE html>
<html lang="en">
<head>
  <title>LEMBAGA KEARSIPAN NASIONAL</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url()?>assets/css/daftar.css">
  <script src="<?php echo base_url() ?>assets/js/jquery.min.js"></script>
  <script src="<?php echo base_url() ?>assets/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <img src="<?php echo base_url() ?>assets/img/logo_anri.jpg" width="300"><h2>LEMBAGA KEARSIPAN NASIONAL</h2>
  <p>Pendataan untuk Lembaga kearsipan Nasional (Provinsi, Kabupaten, Kota)</p>

  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Lembaga</a></li>
    <li><a data-toggle="tab" href="#menu1">Sarana Prasarana</a></li>
    <li><a data-toggle="tab" href="#menu2">Sistem Pengolahan</a></li>
    <li><a data-toggle="tab" href="#menu3">SDM Arsiparis</a></li>
    <li><a data-toggle="tab" href="#menu4">Data Arsip</a></li>
    <li><a data-toggle="tab" href="#menu5">GNSTA</a></li>
    <li><a data-toggle="tab" href="#menu6">Anggaran</a></li>
    <li><a data-toggle="tab" href="#menu7">Peraturan</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <h3>DATA LEMBAGA</h3>
      <h4>Isi data lembaga sesuai dengan data yang ada </h4>
      <?php echo form_open('user/aksi_tambah_anggran'); ?>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                <div class="row">
                  <div class="col-md-6 col-lg-6">
                   <div class="form-group">
                      <label for="username">Username</label>
                      <input type="text" name="username" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="password">Password</label>
                      <input type="password" id="password" name="password" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="username">Nama Lembaga Kearsipan</label>
                      <input type="text" name="nama_lkd" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="username">Wilayah</label>
                      <input type="text" name="wilayah" required="required" class="form-control"/>
                    </div>
                    <div class="form-group" >
                      <label for="username">Status Wilayah</label>
                      <select name="statuswilayah" class="form-control">
                        <option value="1">Profinsi</option>
                        <option value="2">Kabupaten</option>
                        <option value="3">Kota</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="text">Nomen Kelatur</label>
                      <input type="text" id="nomenklatur" name="nomenklatur" required="required" class="form-control"/>
                    </div>
                    </div>
                    <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                      <label for="text">Dasar Hukum Lembaga</label>
                      <input type="text" id="dasarhukum" name="dasarhukum" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Alamat</label>
                      <textarea name="alamat" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="text">Telp</label>
                      <input type="text" id="telp" name="telp" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Email</label>
                      <input type="text" id="email" name="email" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Website</label>
                      <input type="text" id="website" name="website" required="required" class="form-control"/>
                    </div>
                  <div class="form-group">
                    <a href="#menu1" data-toggle="tab">  <input type="button" value="Next" class="btn btn-primary"></a>
                  </div>
                </div>
                </div>
                </div>
              </div>
            </div>
          </div>
    </div>
    <div id="menu1" class="tab-pane fade">
      <h3>DATA SARANA PRASARANA</h3>
      <h4></h4>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                <div class="row">
                  <div class="col-md-12 col-lg-4">
                    <h4><span style="padding: 5px;background-color: #0a4b84;color:#FFF;">CENTRAL FILE</span></h4>
                    <div class="form-group">
                      <label for="text">Jumlah Filling Kabinet</label>
                      <input type="number" id="c_fillingkabinet" name="c_fillingkabinet" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Folder</label>
                      <input type="number" id="c_folder" name="c_folder" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Guide</label>
                      <input type="number" id="c_guide" name="c_guide" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Map Gantung</label>
                      <input type="number" id="c_mapgantung" name="c_mapgantung" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Out Indikator</label>
                      <input type="number" id="c_outindikator" name="c_outindikator" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Buku Peminjaman</label>
                      <input type="number" id="c_bukupeminjaman" name="c_bukupeminjaman" required="required" class="form-control"/>
                    </div>
                  </div>

                <div class="col-md-12 col-lg-4">
                  <h4><span style="padding: 5px;background-color: #8e2c00;color:#FFF;">RECORD CENTER</span></h4>
                    <div class="form-group">
                      <label for="text">Jumlah Rak Arsip</label>
                      <input type="number" id="r_rakarsip" name="r_rakarsip" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text"> Jumlah Boks </label>
                      <input type="number" id="r_boks" name="r_boks" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Folder</label>
                      <input type="number" id="r_folder" name="c_folder" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Out Indikator</label>
                      <input type="number" id="r_outindikator" name="c_outindikator" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Buku Peminjaman</label>
                      <input type="number" id="r_bukupeminjaman" name="c_bukupeminjaman" required="required" class="form-control"/>
                    </div>
                </div>
                <div class="col-md-12 col-lg-4">
                  <h4><span style="padding: 5px;background-color: #008e03;color:#FFF;">DEPO</span></h4>
                    <div class="form-group">
                      <label for="text">Jumlah Rak Arsip</label>
                      <input type="number" id="d_rakarsip" name="r_rakarsip" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text"> Jumlah Boks </label>
                      <input type="number" id="d_boks" name="r_boks" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Folder</label>
                      <input type="number" id="d_folder" name="c_folder" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Out Indikator</label>
                      <input type="number" id="d_outindikator" name="c_outindikator" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Buku Peminjaman</label>
                      <input type="number" id="d_bukupeminjaman" name="c_bukupeminjaman" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                    <a href="#menu3" data-toggle="tab">  <input type="button" value="Next" class="btn btn-primary"></a>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
   
    <div id="menu2" class="tab-pane fade">
      <h3>SISTEM PENGOLAHAN KEARSIPAN</h3>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                <div class="row">
                  <div class="col-md-12 col-lg-4">
                  <h4><span style="padding: 5px;background-color: #0a4b84;color:#FFF;">SIKD</span></h4>
                   <div class="form-group">
                      <label for="text">Terima SIKD</label>
                      <br>
                      <label><input type="radio" name="sikd_terima" value="0"> Belum</label>
                      <label><input type="radio" name="sikd_terima" value="1"> Sudah</label>
                      <label><input type="radio" name="sikd_terima" value="2"> Sedang Proses</label>
                    </div>
                    <div class="form-group">
                      <label for="text">Implementasi SIKD</label>
                      <br>
                      <label><input type="radio" name="sikd_implementasi" value="0"> Belum</label>
                      <label><input type="radio" name="sikd_implementasi" value="1"> Sudah</label>
                      <label><input type="radio" name="sikd_implementasi" value="2"> Sedang Proses</label>
                    </div>
                    <div class="form-group">
                      <label for="text">Tanggal Terima SIKD</label>
                      <input type="date" id="sikd_tanggal" name="sikd_tanggal" required="required" class="form-control"/>
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-4">
                  <h4><span style="padding: 5px;background-color: #8e2c00;color:#FFF;">SIKS</span></h4>  
                  <div class="form-group">
                      <label for="text">Terima SIKS</label>
                      <br>
                      <label><input type="radio" name="siks_terima" value="0"> Belum</label>
                      <label><input type="radio" name="siks_terima" value="1"> Sudah</label>
                      <label><input type="radio" name="siks_terima" value="2"> Sedang Proses</label>
                    </div>
                    <div class="form-group">
                      <label for="text">Implementasi SIKS</label>
                      <br>
                      <label><input type="radio" name="siks_implementasi" value="0"> Belum</label>
                      <label><input type="radio" name="siks_implementasi" value="1"> Sudah</label>
                      <label><input type="radio" name="siks_implementasi" value="2"> Sedang Proses</label>
                    </div>
                    <div class="form-group">
                      <label for="text">Tanggal Terima SIKS</label>
                      <input type="date" id="siks_tanggal" name="siks_tanggal" required="required" class="form-control"/>
                    </div>
                    
                </div>
                <div class="col-md-12 col-lg-4">
                  <h4><span style="padding: 5px;background-color: #008e03;color:#FFF;">SIKN</span></h4>
                    <div class="form-group">
                      <label for="text">Anggota Simpul Jaringan Nasional</label>
                      <br>
                      <label><input type="radio" name="sikn_simpul" value="0"> Belum</label>
                      <label><input type="radio" name="sikn_simpul" value="1"> Sudah</label>
                      <label><input type="radio" name="sikn_simpul" value="2"> Sedang Proses</label>
                    </div>
                    <div class="form-group">
                      <label for="text">Implementasi SIKN</label>
                      <br>
                      <label><input type="radio" name="sikn_implementasi" value="0"> Belum</label>
                      <label><input type="radio" name="sikn_implementasi" value="1"> Sudah</label>
                      <label><input type="radio" name="sikn_implementasi" value="2"> Sedang Proses</label>
                    </div>
                    <div class="form-group">
                      <label for="text">Tanggal Terima SIKN</label>
                      <input type="date" id="sikn_tanggal" name="sikn_tanggal" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                    <a href="#menu6" data-toggle="tab">  <input type="button" value="Next" class="btn btn-primary"></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
     <div id="menu3" class="tab-pane fade">
      <h3>SDM KEARSIPAN</h3>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                <div class="row">
                  <div class="col-md-6 col-lg-6">
                  <h4><span style="padding: 5px;background-color: #0a4b84;color:#FFF;"> ARSIPARIS TERAMPIL </span></h4>
                   <div class="form-group">
                      <label for="text">Pelaksana</label>
                      <input type="text" name="arsiparis_terampil_pelaksana" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Pelaksana Lanjutan</label>
                      <input type="text" id="arsiparis_terampil_pelaksana_lanjutan" name="arsiparis_terampil_pelaksana_lanjutan" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Penyelia</label>
                      <input type="text" name="arsiparis_terampil_penyelia" required="required" class="form-control"/>
                    </div>
                    <h4><span style="padding: 5px;background-color: #8e2c00;color:#FFF;">NON ARSIPARIS</span></h4>
                     <div class="form-group">
                        <label for="text">Jumlah Non Arsiparis</label>
                        <input type="text" name="tenaga_non_arsiparis" required="required" class="form-control"/>
                     </div>
                  </div>
                  <div class="col-md-6 col-lg-6">
                  <h4><span style="padding: 5px;background-color: #008e03;color:#FFF;">ARSIPARIS AHLI</span></h4>
                   <div class="form-group">
                      <label for="text">Pertama</label>
                      <input type="text" name="arsipari_ahli_pertama" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Muda</label>
                      <input type="text" id="arsipari_ahli_muda" name="arsipari_ahli_muda" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Madya</label>
                      <input type="text" name="arsipari_ahli_madya" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Utama</label>
                      <input type="text" name="arsipari_ahli_utama" required="required" class="form-control"/>
                    </div>
                    
                    <div class="form-group">
                        <a href="#menu5" data-toggle="tab">  <input type="button" value="Next" class="btn btn-primary"></a>
                    </div>
                  </div>

                </div>
                </div>
              </div>
            </div>
          </div>
    </div>
    <div id="menu4" class="tab-pane fade">
      <h3>DATA ARSIP</h3>

      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                <div class="row">
                <div class="col-md-12 col-lg-4">
                  <h4><span style="padding: 5px;background-color: #0a4b84;color:#FFF;">Data Arsip Aktif</span></h4>
                    <div class="form-group">
                      <label for="text">Daftar Berkas</label>
                      <input type="text" id="aa_daftar_berkas" name="aa_daftar_berkas" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Daftar Isi Berkasi</label>
                      <input type="text" id="aa_daftar_isi_berkas" name="aa_daftar_isi_berkas" required="required" class="form-control"/>
                    </div>
                    <h4>Media Arsip</h4>
                    <div class="form-group">
                      <label for="text">Kertas</label>
                      <input type="text" id="aa_kertas" name="aa_kertas" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Foto</label>
                      <input type="text" id="aa_foto" name="aa_foto" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Film</label>
                      <input type="text" id="aa_film" name="aa_film" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Kartografi dan Kearsitekturan</label>
                      <input type="text" id="aa_kartografi_kearsitekturan" name="aa_kartografi_kearsitekturan" required="required" class="form-control"/>
                    </div>
                    <h4><span style="padding: 5px;background-color: #8e2c00;color:#FFF;">Data Arsip Vital</span></h4>
                    <div class="form-group">
                      <label for="text">Daftar Arsip</label>
                      <input type="text" id="av_daftar" name="av_daftar" required="required" class="form-control"/>
                    </div>
                    <h4>Media Arsip</h4>
                    <div class="form-group">
                      <label for="text">Kertas</label>
                      <input type="text" id="av_kertas" name="av_kertas" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Foto</label>
                      <input type="text" id="av_foto" name="av_foto" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Film</label>
                      <input type="text" id="av_film" name="av_film" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Kartografi dan Kearsitekturan</label>
                      <input type="text" id="av_kartografi_kearsitekturan" name="av_kartografi_kearsitekturan" required="required" class="form-control"/>
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-4">
                  <h4><span style="padding: 5px;background-color: #84008e;color:#FFF;">Data Arsip Terjaga</span></h4>
                    <div class="form-group">
                      <label for="text">Daftar Arsip</label>
                      <input type="text" id="at_daftar" name="at_daftar" required="required" class="form-control"/>
                    </div>
                    <h4>Media Arsip</h4>
                    <div class="form-group">
                      <label for="text">Kertas</label>
                      <input type="text" id="at_kertas" name="at_kertas" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Foto</label>
                      <input type="text" id="at_foto" name="at_foto" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Film</label>
                      <input type="text" id="at_film" name="at_film" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Kartografi dan Kearsitekturan</label>
                      <input type="text" id="at_kartografi_kearsitekturan" name="at_kartografi_kearsitekturan" required="required" class="form-control"/>
                    </div>
                    <h4><span style="padding: 5px;background-color: #8e8800;color:#FFF;">Data Arsip Inaktif</span></h4>
                    <div class="form-group">
                      <label for="text">Daftar Arsip</label>
                      <input type="text" id="ai_daftar_berkas" name="ai_daftar_berkas" required="required" class="form-control"/>
                    </div>
                    <h4>Media Arsip</h4>
                    <div class="form-group">
                      <label for="text">Kertas</label>
                      <input type="text" id="ai_kertas" name="ai_kertas" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Foto</label>
                      <input type="text" id="ai_foto" name="ai_foto" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Film</label>
                      <input type="text" id="ai_film" name="ai_film" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Kartografi dan Kearsitekturan</label>
                      <input type="text" id="ai_kartografi_kearsitekturan" name="ai_kartografi_kearsitekturan" required="required" class="form-control"/>
                    </div>
                  </div>
                  <div class="col-md-12 col-lg-4">
                  <h4><span style="padding: 5px;background-color: #008e03;color:#FFF;">Data Arsip Statis</span></h4>
                    <div class="form-group">
                      <label for="text">Daftar Berkas</label>
                      <input type="text" id="ai_daftar_berkas" name="ai_daftar_berkas" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Inventaris Arsip</label>
                      <input type="text" id="ai_daftar_isi_berkas" name="ai_daftar_isi_berkas" required="required" class="form-control"/>
                    </div>
                    <h4>Media Arsip</h4>
                    <div class="form-group">
                      <label for="text">Kertas</label>
                      <input type="text" id="ai_kertas" name="ai_kertas" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Foto</label>
                      <input type="text" id="ai_foto" name="ai_foto" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Film</label>
                      <input type="text" id="ai_film" name="ai_film" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Kartografi dan Kearsitekturan</label>
                      <input type="text" id="ai_kartografi_kearsitekturan" name="ai_kartografi_kearsitekturan" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                        <a href="#menu5" data-toggle="tab">  <input type="button" value="Next" class="btn btn-primary"></a>
                    </div>
                  </div>                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="menu5" class="tab-pane fade">
      <h3>GERAKAN NASIONAL SADAR TERTIB ARSIP</h3>
      <h4></h4>
      <?php echo form_open('user/aksi_tambah_anggran'); ?>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                <div class="row">
                  <div class="col-md-12 col-lg-12">
                   <div class="form-group">
                      <label for="text">Kegiatan</label>
                      <textarea rows="10" name="gnsta_uraian" required="required" class="form-control" ></textarea>
                    </div>
                    <div class="form-group">
                      <label for="text">Tanggal Pelaksanaan</label>
                      <input type="date" id="gnsta_tgl" name="gnsta_tgl" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                        <a href="#menu5" data-toggle="tab">  <input type="button" value="Next" class="btn btn-primary"></a>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="menu6" class="tab-pane fade">
      <h3>Anggaran Kearsipan</h3>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                <div class="row">
                  <div class="col-md-12 col-lg-12">
                   <div class="form-group">
                      <label for="text">Jumlah Anggaran Lembaga Kearsipan</label>
                      <input type="text" id="anggaran_lkd_kearsipan" name="anggaran_lkd_kearsipan" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Jumlah Anggaran Lembaga Perpustakaan</label>
                      <input type="text" id="anggaran_lkd_perpustakaan" name="anggaran_lkd_perpustakaan" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Tahun</label>
                      <input type="text" id="tahun" name="tahun" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                        <a href="#menu5" data-toggle="tab">  <input type="button" value="Next" class="btn btn-primary"></a>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="menu7" class="tab-pane fade">
      <h3>DATA PERATURAN</h3>
      <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                <div class="row">
                  <div class="col-md-12 col-lg-12">
                   <div class="form-group">
                      <label for="text">Peraturan Kearsipan Daerah</label>
                      <textarea rows="3" name="gnsta_uraian" required="required" class="form-control" ></textarea>
                    </div>
                    <div class="form-group">
                      <label for="text">Peraturan Kearsipan Kepala Daerah</label>
                      <textarea rows="3" name="gnsta_uraian" required="required" class="form-control" ></textarea>
                    </div>
                    <div class="form-group">
                      <label for="text">Peraturan Kearsipan Edaran</label>
                      <textarea rows="3" name="gnsta_uraian" required="required" class="form-control" ></textarea>
                    </div>
                    <div class="form-group">
                      <label for="text">Peraturan Kearsipan </label>
                      <textarea rows="3" name="gnsta_uraian" required="required" class="form-control" ></textarea>
                    </div>
                    <div class="form-group">
                      <label for="text">Peraturan Kearsipan Tata Naskah Dinas</label>
                      <textarea rows="3" name="gnsta_uraian" required="required" class="form-control" ></textarea>
                    </div>
                    <div class="form-group">
                      <label for="text">Peraturan Kearsipan Klasifikasi</label>
                      <textarea rows="3" name="gnsta_uraian" required="required" class="form-control" ></textarea>
                    </div>
                    <div class="form-group">
                      <label for="text">Peraturan Kearsipan Jadwal Retensi Arsip</label>
                      <textarea rows="3" name="gnsta_uraian" required="required" class="form-control" ></textarea>
                    </div>
                     <div class="form-group">
                      <label for="text">Peraturan Kearsipan Keamanan Klasifikasi Arsip</label>
                      <textarea rows="3" name="gnsta_uraian" required="required" class="form-control" ></textarea>
                    </div>
                    <div class="form-group">
                        <a href="#menu5" data-toggle="tab">  <input type="button" value="SIMPAN" class="btn btn-primary btn-lg"></a>

                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>