<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"><?php echo $judul;?></h4>
					</div>
					<?php echo form_open('user/update_profil'); ?>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<?php foreach ($profil as $p): ?>

										<div class="form-group">
											<label for="">Nama Pengelola</label>
											<?php echo form_input('nama', $p->nama, 'Nama Anda" class="form-control"'); ?>
										</div>
										<div class="form-group">
											<label for="">Unit Kerja</label>
											<?php echo form_input('unit_kerja', $p->unit_kerja, 'placeholder="Silahkan Isi Unit Kerja Anda" class="form-control"'); ?>
										</div>
										<div class="form-group">
											<label for="">Jabatan</label>
											<?php echo form_input('jabatan', $p->jabatan, 'placeholder="Silahkan Isi Jabatan Anda" class="form-control"'); ?>
										</div>
										<div class="form-group">
											<label for="">No HP</label>
											<?php echo form_input('no_hp', $p->no_hp, 'placeholder="Silahkan Isi No HP Anda" class="form-control"'); ?>
										</div>		
										<div class="form-group">
											<label for="">Username</label>
											<?php echo form_input('', $p->username, 'disabled placeholder="Silahkan Isi Telp Anda" class="form-control"'); ?>
										</div>	
										<div class="form-group">
											<label for="">Password</label>
											<?php echo form_input('password', '', ' placeholder="Ubah Password, jika tidak mengubah maka kosongkan saja" class="form-control"'); ?>
										</div>								
										<?php endforeach ?>
										<div class="form-group">
											<?php echo form_submit('submit', 'EDIT', 'class="btn btn-primary"'); ?>
											<?php echo form_close(); ?>
										</div>
								</div>
							</div>
						</div>
					</div>
				</div>