			<div class="page-inner">
			    <div class="page-header">
			        <h4 class="page-title"><?php echo $judul; ?></h4>
			    </div>
			    <?php echo form_open('user/aksi_edit_sdm'); ?>
			    <?php foreach ($record as $r) : ?>
			        <div class="row">
			            <div class="col-md-12">
			                <div class="card">
			                    <div class="card-body">
			                        <div class="form-group">
										<label for="">Jumlah Arsiparis Terampil</label>
										<?php echo form_input('arsiparis_terampil',$r->arsiparis_terampil, 'placeholder="Jumlah Arsiparis Terampil" class="form-control"'); ?>
									</div>
									<div class="form-group">
										<label for="">Jumlah Arsiparis Mahir</label>
										<?php echo form_input('arsiparis_mahir',$r->arsiparis_mahir, 'placeholder="Jumlah Arsiparis Mahir" class="form-control"'); ?>
									</div>
									<div class="form-group">
										<label for="">Jumlah Arsiparis Penyelia</label>
										<?php echo form_input('arsiparis_penyelia',$r->arsiparis_penyelia, 'placeholder="Jumlah Arsiparis Penyelia" class="form-control"'); ?>
									</div>
									<div class="form-group">
										<label for="">Jumlah Arsiparis Pertama</label>
										<?php echo form_input('arsiparis_pertama',$r->arsiparis_pertama, 'placeholder="Jumlah Arsiparis Pertama" class="form-control"'); ?>
									</div>
									<div class="form-group">
										<label for="">Jumlah Arsiparis Muda</label>
										<?php echo form_input('arsiparis_muda',$r->arsiparis_muda, 'placeholder="Jumlah Arsiparis Muda" class="form-control"'); ?>
									</div>
									<div class="form-group">
										<label for="">Jumlah Arsiparis Madya</label>
										<?php echo form_input('arsiparis_madya',$r->arsiparis_madya, 'placeholder="Jumlah Arsiparis Madya" class="form-control"'); ?>
									</div>
									<div class="form-group">
										<label for="">Jumlah Non Arsiparis</label>
										<?php echo form_input('tenaga_non_arsiparis',$r->tenaga_non_arsiparis, 'placeholder="Jumlah Non Arsiparis" class="form-control"'); ?>
									</div>

			                        <div class="form-group">
			                            <label for="">TAHUN</label>
                                        <?php echo form_input('tahun', $r->tahun, 'placeholder="2018" class="form-control"'); ?>
                                        <input type="hidden" name="id_sdm" value="<?= $r->id_sdm ?>">
			                        </div>

			                        
			                        <div class="form-group">
			                            <?php echo form_submit('submit', 'UPDATE', 'class="btn btn-primary"'); ?>
			                        <?php echo form_close(); ?>
			                        </div>
			                    </div>
			                </div>
			            </div>
			        </div>
			    </div>
			</div>
<?php endforeach; ?>