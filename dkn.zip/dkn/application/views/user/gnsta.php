<div class="page-inner">
	<div class="page-header">
		<h4 class="page-title"><?php echo $judul; ?></h4>
	</div>
	<p>
		<a href="<?= base_url('index.php/user/tambah_gnsta') ?>"><button class="btn btn-primary">TAMBAH</button></a>
	</p>
	<div class="row">
		<div class="col-md-12">
			<div class="card">

				<div class="card-body">
					<div class="table-responsive">
						<table id="basic-datatables" class="display table table-striped table-hover">
							<thead>
								<tr>
									<th>GNSTA Uraian</th>
									<th>Tanggal Pelaksanaan</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($gnsta as $record) { ?>
									<tr>
										<td><?php echo $record->gnsta_uraian; ?></td>
										<td><?php echo $record->gnsta_tgl; ?></td>
										<td>
											<a href="<?= base_url('user/edit_gnsta/' . $record->id_gnsta) ?>" class="btn btn-xs btn-primary"><i class="fa fa-pen"></i></a>
											<a href="<?= base_url('user/hapus_gnsta/' . $record->id_gnsta) ?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
