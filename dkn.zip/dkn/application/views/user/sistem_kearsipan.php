<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"><?php echo $judul;?></h4>
					</div>
					<?php echo form_open('user/aksi_sistem_informasi'); ?>
					<div class="row">
						<div class="col-md-12">
							<div class="card"> 
								<div class="card-body">
									<div class="row">

										<?php if ($sistem) : ?>
											<?php foreach ($sistem as $p): ?>
										<div class="col-md-6 col-lg-4">
												<div class="form-group">
													<h3>SIKD</h3>
													<label for="">Menggunakan SIKD</label>
													<label>
													<?php if($p->sikd_terima>=1):?>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio1" name="sikd_terima" class="custom-control-input" checked="">
													  <label class="custom-control-label" for="customRadio1">Iya</label>
													</div>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio2" name="sikd_terima" class="custom-control-input">
													  <label class="custom-control-label" for="customRadio2">Belum</label>
													</div>
												<?php else: ?>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio1" name="sikd_terima" class="custom-control-input" >
													  <label class="custom-control-label" for="customRadio1">Iya</label>
													</div>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio2" name="sikd_terima" class="custom-control-input" checked="">
													  <label class="custom-control-label" for="customRadio2">Belum</label>
													</div>
													<?php endif	?>
													</label>
												</div>
												<div class="form-group">
													<label for="">Tahun SIKD</label>
													<?php echo form_input('sikd_tanggal', $p->sikd_tanggal, 'placeholder="Tanggal terima SIKD" class="form-control"'); ?>
												</div>
										</div>
										<div class="col-md-6 col-lg-4">
											
												<div class="form-group">
													<h3>SIKS</h3>
													<label for="">Menggunakan SIKS</label>
													<label>
													<?php if($p->siks_terima>=1):?>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio3" name="siks_terima" class="custom-control-input" checked="">
													  <label class="custom-control-label" for="customRadio3">Iya</label>
													</div>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio4" name="siks_terima" class="custom-control-input">
													  <label class="custom-control-label" for="customRadio4">Belum</label>
													</div>
												<?php else: ?>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio3" name="siks_terima" class="custom-control-input" >
													  <label class="custom-control-label" for="customRadio3">Iya</label>
													</div>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio4" name="siks_terima" class="custom-control-input" checked="">
													  <label class="custom-control-label" for="customRadio4">Belum</label>
													</div>
													<?php endif	?>
													</label>
												</div>
												<div class="form-group">
													<label for="">Tahun SIKS</label>
													<?php echo form_input('siks_tanggal', $p->siks_tanggal, 'class="form-control"'); ?>
												</div>
										</div>
										<div class="col-md-6 col-lg-4">
											
												<div class="form-group">
													<h3>SIKN/JIKN</h3>
													<label for="">Menggunakan SIKN/JIKN</label>
													<label>
													<?php if($p->sikn_jikn>=1):?>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio5" name="sikn_jikn" class="custom-control-input" checked="">
													  <label class="custom-control-label" for="customRadio5">Iya</label>
													</div>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio6" name="sikn_jikn" class="custom-control-input">
													  <label class="custom-control-label" for="customRadio6">Belum</label>
													</div>
												<?php else: ?>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio5" name="sikn_jikn" class="custom-control-input" >
													  <label class="custom-control-label" for="customRadio5">Iya</label>
													</div>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio6" name="sikn_jikn" class="custom-control-input" checked="">
													  <label class="custom-control-label" for="customRadio6">Belum</label>
													</div>
													<?php endif	?>
												</div>
												<div class="form-group">
													<label for="">Implementasi SIKN</label>
													<?php echo form_input('sikn_jikn_tanggal',$p->sikn_jikn_tanggal, 'class="form-control"'); ?>
												</div>
										</div>
										<div class="col-md-12">
											
												<div class="form-group">
													<h3>SISTEM ARSIP LAINNYA</h3>
													<label for="">Deskripsi Sistem Arsip Lainya</label>
													<?php echo form_textarea('sistem_informasi_lain', $p->sistem_informasi_lain, 'class="form-control"'); ?>
												</div>
												
												<div class="form-group">
													<label for="">Tahun menggunakan Sistem Arsip Lainya</label>
													<?php echo form_input('sistem_informasi_lain_tanggal', $p->sistem_informasi_lain_tanggal, 'class="form-control"'); ?>
												</div>
										</div>
								<?php endforeach ?>
								<?php else : ?>
									<div class="col-md-6 col-lg-4">
												<div class="form-group">
													<h3>SIKD</h3>
													<label for="">Menggunakan SIKD</label>
													<label>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio1" value="1" name="sikd_terima" class="custom-control-input" >
													  <label class="custom-control-label" for="customRadio1">Iya</label>
													</div>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio2" value="0" name="sikd_terima" class="custom-control-input">
													  <label class="custom-control-label" for="customRadio2">Belum</label>
													</div>
													</label>
												</div>
												<div class="form-group">
													<label for="">Tahun SIKD</label>
													<?php echo form_input('sikd_tanggal','','placeholder="Tanggal terima SIKD" class="form-control"'); ?>
												</div>
										</div>
										<div class="col-md-6 col-lg-4">
												<div class="form-group">
													<h3>SIKS</h3>
													<label for="">Menggunakan SIKS</label>
													<label>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio3" value="1" name="siks_terima" class="custom-control-input" >
													  <label class="custom-control-label" for="customRadio3">Iya</label>
													</div>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio4" value="0" name="siks_terima" class="custom-control-input">
													  <label class="custom-control-label" for="customRadio4">Belum</label>
													</div>
													</label>
												</div>
												<div class="form-group">
													<label for="">Tahun SIKD</label>
													<?php echo form_input('siks_tanggal','','placeholder="Tanggal terima SIKD" class="form-control"'); ?>
												</div>
										</div>
										<div class="col-md-6 col-lg-4">
											
												<div class="form-group">
													<h3>SIKD</h3>
													<label for="">Menggunakan SIKN/JIKN</label>
													<label>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio5" value="1" name="sikn_jikn" class="custom-control-input" >
													  <label class="custom-control-label" for="customRadio5">Iya</label>
													</div>
													<div class="custom-control custom-radio">
													  <input type="radio" id="customRadio6" value="0" name="sikn_jikn" class="custom-control-input">
													  <label class="custom-control-label" for="customRadio6">Belum</label>
													</div>
													</label>
												</div>
												<div class="form-group">
													<label for="">Tahun SIKN/JIKN</label>
													<?php echo form_input('sikn_jikn_tanggal','','placeholder="Tanggal terima SIKN/JIKN" class="form-control"'); ?>
												</div>
										</div>
										<div class="col-md-12">
											
												<div class="form-group">
													<h3>SISTEM ARSIP LAINNYA</h3>
													<label for="">Deskripsi Sistem Arsip Lainya</label>
													<?php echo form_textarea('sistem_informasi_lain', '', 'class="form-control"'); ?>
												</div>
												
												<div class="form-group">
													<label for="">Tahun menggunakan Sistem Arsip Lainya</label>
													<?php echo form_input('sistem_informasi_lain_tanggal', '', 'placeholder="Tanggal terima Sistem Arsip Lainnya" class="form-control"'); ?>
												</div>
										</div>
								<?php endif;?>			
									</div>
									<div class="form-group">
									<?php echo form_submit('submit', 'EDIT', 'class="btn btn-primary"'); ?>
									<?php echo form_close(); ?>
									</div>
							</div>
						</div>
					</div>
				</div>