			<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"><?php echo $judul;?></h4>
					</div>
					<?php echo form_open('user/aksi_tambah_gnsta'); ?>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="form-group">
										<label for="">Tanggal / Tahun Pelaksana</label>
										<?php echo form_input('gnsta_tgl','', 'placeholder="2018" class="form-control"'); ?>
									</div>
									<div class="form-group">
										<label for="">Deskripsi</label>
										<?php echo form_textarea('gnsta_uraian','', 'placeholder="Deskripsi Kegiatan" class="form-control"'); ?>
									</div>
								</div>
								<div class="card-action">
										<?php echo form_submit('submit', 'Simpan', 'class="btn btn-primary"'); ?>
										<?php echo form_close(); ?>
								</div>
							</div>
						</div>
					</div>
				</div>