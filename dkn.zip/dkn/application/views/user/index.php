<div class="panel-body">
	<?php echo form_open('user/aksi_login'); ?>
		<legend>Form Login</legend>
				<div class="form-group">
					<label for="">UserName</label>
						<?php echo form_input('username', '', 'placeholder="Silahkan Isi Username Anda" class="form-control"'); ?>
				</div>
				<div class="form-group">
					<label for="">Password</label>
					<?php echo form_password('password', '', 'placeholder="Silahkan Isi Password Anda" class="form-control"'); ?>
				</div>
				<div class="form-group">
					<?php echo form_submit('submit', 'Login', 'class="btn btn-primary"'); ?>
					<?php echo form_close(); ?>
				</div>

</div>