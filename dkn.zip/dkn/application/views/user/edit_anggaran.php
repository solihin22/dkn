<div class="page-inner">
    <div class="page-header">
        <h4 class="page-title"><?php echo $judul; ?></h4>
    </div>
    <?php echo form_open('user/aksi_edit_anggran'); ?>
    <?php foreach ($record as $r) : ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Anggraan LKD Kearsipan</label>
                            <?php echo form_input('anggaran_lkd_kearsipan', $r->anggaran_lkd_kearsipan, 'placeholder="Silahkan Isi Anggaran Kearsipan Anda" class="form-control"'); ?>
                            <input type="hidden" name="id_anggaran" value="<?= $r->id_anggaran ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Anggraan LKD Perpustakaan</label>
                            <?php echo form_input('anggaran_lkd_perpustakaan', $r->anggaran_lkd_perpustakaan, 'placeholder="Silahkan Isi Anggraan Perpustakaan Anda" class="form-control"'); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Tahun</label>
                            <?php echo form_input('tahun', $r->tahun, 'placeholder="Silahkan Isi Tahun Anggraan Anda" class="form-control"'); ?>
                        </div>
                        <div class="form-group">
                            <?php echo form_submit('submit', 'Simpan', 'class="btn btn-primary"'); ?>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>