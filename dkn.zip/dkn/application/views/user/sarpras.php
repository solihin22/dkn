<div class="page-inner">
	<div class="page-header">
		<h4 class="page-title"><?php echo $judul; ?></h4>
	</div>
	<p>
		<a href="<?= base_url('index.php/user/tambah_sarpras') ?>"><button class="btn btn-primary">TAMBAH</button></a>
	</p>
	<div class="row">
		<div class="col-md-12">
			<div class="card">

				<div class="card-body">
					<div class="table-responsive">
						<table id="basic-datatables" class="display table table-striped table-hover">
							<thead>
								<tr>
									<th>Depo Arsip</th>
									<th>Record Center</th>
									<th>Tahun</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($sarpras	as $record) { ?>
									<tr>
										<td><?php echo $record->depo; ?></td>
										<td><?php echo $record->record_center; ?></td>
										<td><?php echo $record->tahun; ?></td>
										<td>
											<a href="<?= base_url('user/edit_sarpras/' . $record->id_sarpras) ?>" class="btn btn-xs btn-primary"><i class="fa fa-pen"></i></a>
											<a href="<?= base_url('user/hapus_sarpras/' . $record->id_sarpras) ?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>