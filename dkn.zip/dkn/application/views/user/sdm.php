<div class="page-inner">
	<div class="page-header">
		<h4 class="page-title"><?php echo $judul; ?></h4>
	</div>
	<p><a href="<?= base_url('index.php/user/tambah_sdm') ?>"><button class="btn btn-primary">TAMBAH</button></a></p>
	<div class="row">
		<div class="col-md-12">
			<div class="card">

				<div class="card-body">
					<div class="table-responsive">
						<table id="basic-datatables" class="display table table-striped table-hover">
							<thead>
								<tr>
									<th>Arsiparis Terampil</th>
									<th>Arsiparis Mahir</th>
									<th>Arsiparis Penyelia</th>
									<th>Arsiparis Pertama</th>
									<th>Arsiparis Muda</th>
									<th>Arsiparis Madya</th>
									<th>Tenaga Non Arsiparis</th>
									<th>Tahun</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($sdm	as $record) { ?>
									<tr>
										<td><?php echo $record->arsiparis_terampil; ?></td>
										<td><?php echo $record->arsiparis_mahir; ?></td>
										<td><?php echo $record->arsiparis_penyelia; ?></td>
										<td><?php echo $record->arsiparis_pertama; ?></td>
										<td><?php echo $record->arsiparis_muda; ?></td>
										<td><?php echo $record->arsiparis_madya; ?></td>
										<td><?php echo $record->tenaga_non_arsiparis; ?></td>
										<td><?php echo $record->tahun; ?></td>
										<td>
											<a href="<?= base_url('user/edit_sdm/' . $record->id_sdm) ?>" class="btn btn-xs btn-primary"><i class="fa fa-pen"></i></a>
											<a href="<?= base_url('user/hapus_sdm/' . $record->id_sdm) ?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>