<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"><?php echo $judul;?></h4>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
												<tr>
													<th>Terima SIKD</th>
													<th>Implementasi SIKD</th>
													<th>Tanggal SIKS</th>
													<th>Terima SIKS</th>
													<th>Implementasi SIKS</th>
													<th>Tanggal SIKS</th>
													<th>Terima SIKN</th>
													<th>Implementasi SIKN</th>
													<th>Tanggal SIKN</th>
												</tr>
											</thead>
											<tbody>
											<?php foreach ($sistem	as $record){ ?>
												<tr>
													<td><?php echo $record->sikd_terima;?></td>
													<td><?php echo $record->sikd_implementasi;?></td>
													<td><?php echo $record->sikd_tanggal;?></td>
													<td><?php echo $record->siks_terima;?></td>
													<td><?php echo $record->siks_implementasi;?></td>
													<td><?php echo $record->siks_tanggal;?></td>
													<td><?php echo $record->sikn_simpul?></td>
													<td><?php echo $record->sikn_implementasi;?></td>
													<td><?php echo $record->sikn_tanggal;?></td>
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>