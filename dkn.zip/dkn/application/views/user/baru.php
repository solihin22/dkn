<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Login Form - Modal</title>
  
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/reset.min.css">

  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900|Material+Icons'>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/daftar.css">
</head>
<body>
<div class="container">
<!-- Form-->
<!--      <h1 align="center"><img src="<?php echo base_url();?>assets/img/logo_anri.jpg" width="350"></h1>-->
    <h3 align="center">PENDAFTARAN LEMBAGA KEARSIPAN</h3>
      <?php if (@$this->session->flashdata('error')) : ?>
      <div class="alert alert-danger" role="alert">
        <?= $this->session->flashdata('error') ?>
      </div>
    <?php endif; ?>

      <?php echo form_open('login/daftar'); ?>
        <div class="row">
          <div class="col-md-12">
            <div class="row">
                  <div class="col-md-6 col-lg-6">
                   <div class="form-group">
                      <label for="username">Username</label>
                      <input type="text" name="username" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="password">Password</label>
                      <input type="password" id="password" name="password" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="username">Nama Lembaga Kearsipan</label>
                      <input type="text" name="nama_lkd" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="username">Wilayah</label>
                      <input type="text" name="wilayah" required="required" class="form-control"/>
                    </div>
                    <div class="form-group" >
                      <label for="username">Status Wilayah</label>
                      <select name="statuswilayah" class="form-control">
                        <option value="1">Profinsi</option>
                        <option value="2">Kabupaten</option>
                        <option value="3">Kota</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="text">Nomen Kelatur</label>
                      <input type="text" id="nomenklatur" name="nomenklatur" required="required" class="form-control"/>
                    </div>
                    </div>
                    <div class="col-md-6 col-lg-6">
                    <div class="form-group">
                      <label for="text">Dasar Hukum Lembaga</label>
                      <input type="text" id="dasarhukum" name="dasarhukum" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Telp</label>
                      <input type="text" id="telp" name="telp" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Email</label>
                      <input type="text" id="email" name="email" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Website</label>
                      <input type="text" id="website" name="website" required="required" class="form-control"/>
                    </div>
                    <div class="form-group">
                      <label for="text">Alamat</label>
                      <textarea name="alamat" class="form-control" rows="5"></textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                      <button type="submit" class="btn btn-primary">DAFTAR</button>
                      <?php echo form_close(); ?>
                      <a href="<?php echo base_url();?>"><button type="button" class="btn btn-danger">KEMBALI</button>
                      <?php echo form_close(); ?>
                    </div>
                </div>
              </div>
          </div>
      </form>
    </div>
</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://codepen.io/andytran/pen/vLmRVp.js'></script>
    <script  src="<?php echo base_url();?>assets/js/index.js"></script>
</body>
</html>