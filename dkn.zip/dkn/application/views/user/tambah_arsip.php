			<div class="page-inner">
			    <div class="page-header">
			        <h4 class="page-title"><?php echo $judul; ?></h4>
			    </div>
			    <?php echo form_open('user/aksi_tambah_arsip'); ?>
			    <div class="row">
			        <div class="col-md-12">
			            <div class="card">
			                <div class="card-body">
			                    <div class="row">
			                        <div class="col-md-12 col-lg-6">
			                            <div class="form-group">
			                                <h3 class="text-uppercase mb-3">Data Arsip Statis</h3>
			                                <label for="text">Jumlah Arsip Statis</label>
			                                <input type="text" id="arsip_statis" name="arsip_statis" required="required" class="form-control" />
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Kertas</label>
			                                <input type="text" id="as_kertas" name="as_kertas" required="required" class="form-control" />
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Foto</label>
			                                <input type="text" id="as_foto" name="as_foto" required="required" class="form-control" />
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Film</label>
			                                <input type="text" id="as_film" name="as_film" required="required" class="form-control" />
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Kartografi dan Kearsitekturan</label>
			                                <input type="text" id="as_kartografidankearsitekturan" name="as_kartografidankearsitekturan" required="required" class="form-control" />
			                            </div>
			                        </div>
			                        <div class="col-md-12 col-lg-6">
			                            <div class="form-group">
			                                <h3 class="text-uppercase mb-3">Data Arsip Inaktif</h3>
			                                <label for="text">Jumlah Arsip Inaktif</label>
			                                <input type="text" id="arsip_inaktif" name="arsip_inaktif" required="required" class="form-control" />
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Kertas</label>
			                                <input type="text" id="ai_kertas" name="ai_kertas" required="required" class="form-control" />
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Foto</label>
			                                <input type="text" id="ai_foto" name="ai_foto" required="required" class="form-control" />
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Film</label>
			                                <input type="text" id="ai_film" name="ai_film" required="required" class="form-control" />
			                            </div>
			                            <div class="form-group">
			                                <label for="text">Jumlah Arsip Kartografi dan Kearsitekturan</label>
			                                <input type="text" id="ai_kartografidankearsitekturan" name="ai_kartografidankearsitekturan" required="required" class="form-control" />
			                            </div>
			                        </div>    
			                    </div>
			                    <div class="form-group">
			                        <label for="">TAHUN</label>
			                        <?php echo form_input('tahun', '', 'placeholder="2018" class="form-control"'); ?>
			                    </div>
			                </div>
			                <div class="card-action">
			                	<div class="form-group">
			                        <?php echo form_submit('submit', 'Simpan', 'class="btn btn-primary"'); ?>
			                        <?php echo form_close(); ?>
			                    </div>
			                </div>
			            </div>
			        </div>
			    </div>
			</div>