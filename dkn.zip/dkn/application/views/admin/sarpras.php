<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"><?php echo $judul;?></h4>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover">
										<thead>
											<tr>
												<th>Username</th>
												<th>Depo Arsip</th>
												<th>Record Center</th>
												<th>Tahun</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody>
											<?php foreach ($records	as $record) { ?>
												<tr>
													<td><?php echo $record->username; ?></td>
													<td><?php echo $record->depo; ?></td>
													<td><?php echo $record->record_center; ?></td>
													<td><?php echo $record->tahun; ?></td>
													<td>
														<a href="<?= base_url('admin/detail_sarpras/' . $record->id_sarpras) ?>" class="btn btn-primary btn-sm"><i class="fa fa-search"></i></a>
													</td>
												</tr>
										<?php } ?>
										</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
