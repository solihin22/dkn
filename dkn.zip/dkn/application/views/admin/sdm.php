<div class="page-inner">
	<div class="page-header">
		<h4 class="page-title"><?php echo $judul; ?></h4>
	</div>

	<div class="row">
		<div class="col-md-12">
			<div class="card">

				<div class="card-body">
					<div class="table-responsive">
						<table id="basic-datatables" class="display table table-striped table-hover">
							<thead>
								<tr> 
									<th>Username</th>
									<th>Arsiparis Terampil</th>
									<th>Arsiparis Mahir</th>
									<th>Arsiparis Penyelia</th>
									<th>Arsiparis Pertama</th>
									<th>Arsiparis Muda</th>
									<th>Arsiparis Madya</th>
									<th>Tenaga Non Arsiparis</th>
									<th>Tahun</th>
									<th>Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($records	as $record) { ?>
									<tr>
										<td><?php echo $record->username; ?></td>
										<td><?php echo $record->arsiparis_terampil; ?></td>
										<td><?php echo $record->arsiparis_mahir; ?></td>
										<td><?php echo $record->arsiparis_penyelia; ?></td>
										<td><?php echo $record->arsiparis_pertama; ?></td>
										<td><?php echo $record->arsiparis_muda; ?></td>
										<td><?php echo $record->arsiparis_madya; ?></td>
										<td><?php echo $record->tenaga_non_arsiparis; ?></td>
										<td><?php echo $record->tahun; ?></td>
										<td>
											<a href="<?= base_url('admin/detail_sdm/' . $record->id_sdm) ?>" class="btn btn-primary btn-sm"><i class="fa fa-search"></i></a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>