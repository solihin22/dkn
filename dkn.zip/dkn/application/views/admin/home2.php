		<div class="panel-header bg-dark-gradient">
		    <div class="page-inner py-5">
		        <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		            <div>
		                <h2 class="text-white pb-2 fw-bold">Dashboard</h2>
		                <h5 class="text-white op-7 mb-2"><?= $judul ?></h5>

		            </div>
		            <div class="ml-md-auto py-2 py-md-0">
		                <!-- <form action="" method="get">
		                    <select name="tahun" id="" onchange="this.form.submit()" class="form-control">
		                        <option value="<?= date('Y')  ?>" disabled selected>Pilih Tahun</option>
		                        <?php for ($i = (date('Y') - 2); $i <= date('Y'); $i++) : ?>
		                            <option value="<?= $i ?>" <?php if ($i == $tahun) echo 'selected'; ?>><?= $i ?></option>
		                        <?php endfor; ?>
		                    </select>
		                </form> -->
		                <!-- <a href="#" class="btn btn-white btn-border btn-round mr-2">Manage</a>
						<a href="#" class="btn btn-secondary btn-round">Add Customer</a> -->
		            </div>
		        </div>
		    </div>
		</div>
		<div class="page-inner mt--5">
		    <div class="row mt-2">
		        <div class="col-12">
		            <div class="card full-height">
		                <div class="card-body">
		                    <div class="card-title">Sarana dan Prasarana</div>
		                    <div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
		                        <canvas id="d_sarpras"></canvas>
		                    </div>
		                </div>
		            </div>
		        </div>

		        <div class="col-md-6">
		            <div class="card full-height">
		                <div class="card-body">
		                    <div class="card-title">SDM</div>
		                    <div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
		                        <canvas id="d_sdm"></canvas>
		                    </div>
		                </div>
		            </div>
		        </div>

		        <div class="col-md-6">
		            <div class="card full-height">
		                <div class="card-body">
		                    <div class="card-title">Data Arsip</div>
		                    <div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
		                        <canvas id="d_arsip"></canvas>
		                    </div>
		                </div>
		            </div>
		        </div>

		        <div class="col-md-6">
		            <div class="card full-height">
		                <div class="card-body">
		                    <div class="card-title">Anggaran</div>
		                    <div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
		                        <canvas id="d_anggaran"></canvas>
		                    </div>
		                </div>
		            </div>
		        </div>

		        <div class="col-md-6">
		            <div class="card full-height">
		                <div class="card-body">
		                    <div class="card-title">GNSTA</div>
		                    <div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
		                        <canvas id="d_gnsta"></canvas>
		                    </div>
		                </div>
		            </div>
		        </div>

		    </div>
		</div>

		<script>
		    function random_rgba() {
		        let o = Math.round,
		            r = Math.random,
		            s = 255;
		        return 'rgba(' + o(r() * s) + ',' + o(r() * s) + ',' + o(r() * s) + ',' + r().toFixed(1) + ')';
		    }
		    let options = {
		        scales: {
		            yAxes: [{
		                ticks: {
		                    beginAtZero: true,
		                    min: 0
		                }
		            }]
		        },
		        responsive: true
		    };

		    <?php foreach ($chart as $i => $item) : ?>
		        let <?= 'd_' . $i ?> = document.getElementById('<?= 'd_' . $i ?>').getContext('2d');
		        new Chart(<?= 'd_' . $i ?>, {
		            type: 'bar',
		            data: {
		                labels: <?= json_encode($year_range) ?>,
		                datasets: [
		                    <?php foreach ($item as $lkd => $value) : ?> {
		                            label: '<?= $lkd ?>',
		                            backgroundColor: random_rgba(),
		                            borderColor: random_rgba(),
		                            borderWidth: 1,
		                            data: [
		                                <?php
                                        foreach ($year_range as $yr) {
                                            // echo $yr . "<br>";
                                            echo @$value[$yr] ? $value[$yr] : 0;
                                            echo ',';
                                        }
                                        ?>
		                            ]
		                        },
		                    <?php endforeach ?>
		                ]
		            },
		            options: options
		        });
		    <?php endforeach; ?>
		</script>