<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"><?php echo $judul;?></h4>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead> 
												<tr>
													<th>Username</th>
													<th>Terima SIKD</th>
													<th>Tahun Dipergunakan SIKD</th>
													<th>Terima SIKS</th>
													<th>Tahun Dipergunakan SIKS</th>
													<th>Terima SIKN/JIKN</th>
													<th>Tahun Dipergunakan SIKN/JIKN</th>
													<th>Sistem Pengelolaan Arsip lainnya</th>
													<th>Tahun Dipergunakan Sistem Pengelolaan Arsip lainnya</th>
												</tr>
											</thead>
											<tbody>
											<?php foreach ($records	as $record){ ?>
												<tr>
													<td><?php echo $record->username;?></td>
													<td><?php if($record->sikd_terima==0){ echo"Belum"; }else{echo"Sudah";}?></td>
													<td><?php echo $record->sikd_tanggal;?></td>
													<td><?php if($record->siks_terima==0){ echo"Belum"; }else{echo"Sudah";}?></td>
													<td><?php echo $record->siks_tanggal;?></td>
													<td><?php if($record->sikn_jikn==0){ echo"Belum"; }else{echo"Sudah";}?></td>
													<td><?php echo $record->sikn_jikn_tanggal;?></td>
													<td><?php echo $record->sistem_informasi_lain?></td>
													<td><?php echo $record->sistem_informasi_lain_tanggal;?></td>

												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
