<div class="page-inner">
    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">GNSTA</div>
                    <div class="card-category">GNSTA <?= $sub_data['username'] ?></div>
                    <div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
                        <canvas id="gnsta"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let gnsta = document.getElementById('gnsta').getContext('2d');
    new Chart(gnsta, {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_values($field)) ?>,
            datasets: [{
                label: 'Jumlah Kegiatan GNSTA',
                backgroundColor: 'rgba(54, 162, 235, .2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                data: <?= json_encode(array_values($record)) ?>
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                    }
                }]
            }
        }
    });
</script>