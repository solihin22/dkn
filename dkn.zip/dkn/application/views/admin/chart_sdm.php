<div class="page-inner">
    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">SDM</div>
                    <div class="card-category">SDM <?= $sub_data['username'] ?> tahun <?= $sub_data['tahun'] ?></div>
                    <div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
                        <canvas id="sdm"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let sdm = document.getElementById('sdm').getContext('2d');
    new Chart(sdm, {
        type: 'horizontalBar',
        data: {
            labels: <?= json_encode($field) ?>,
            datasets: [{
                label: '<?= date('Y') ?>',
                backgroundColor: 'rgba(54, 162, 235, .2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                data: <?= json_encode(array_values($record)) ?>
            }]
        },
        options: {
            scales: {
                xAxes: [{
                    ticks: {
                        beginAtZero: true,
                    }
                }]
            }
        }
    });
</script>