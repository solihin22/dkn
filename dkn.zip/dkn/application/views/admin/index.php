<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Login Administrator</title>
  
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/reset.min.css">

  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900|Material+Icons'>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
</head>
<body>
<!-- Form-->
<div class="form">
  <div class="form-admin one">
    <div class="form-header">
<!--      <h1 align="center"><img src="<?php echo base_url();?>assets/img/logo_anri.jpg" width="350"></h1>-->
    <h1 align="center">ADMINISTRATOR PLK ANRI</h1>
      <?php if (@$this->session->flashdata('error')) : ?>
      <div class="alert alert-danger" role="alert">
        <?= $this->session->flashdata('error') ?>
      </div>
    <?php endif; ?>
    </div>
    <div class="form-content">
      <?php echo form_open('login/aksi_login_admin'); ?>
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" required="required"/>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required="required"/>
        </div>
        <div class="form-group">
          <button type="submit" style="background-color: #333;">Log In</button>
          <?php echo form_close(); ?>
        </div>
      </form>
    </div>
  </div>
</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://codepen.io/andytran/pen/vLmRVp.js'></script>
    <script  src="<?php echo base_url();?>assets/js/index.js"></script>
</body>
</html>