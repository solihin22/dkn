<div class="page-inner">
    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Data Khasanah Arsip</div>
                    <div class="card-category">Data Arsip <?= $sub_data['username'] ?> tahun <?= $sub_data['tahun'] ?></div>
                    <div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
                        <canvas id="sarpras" height="300px;"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let sarpras = document.getElementById('sarpras').getContext('2d');
    new Chart(sarpras, {
        type: 'horizontalBar',
        data: {
            labels: <?= json_encode($field) ?>,
            datasets: [{
                label: '<?= date('Y') ?>',
                backgroundColor: 'rgba(54, 162, 235, .2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                data: <?= json_encode(array_values($record)) ?>
            }]
        },
        options: {
            scales: {
                xAxes: [{
                    ticks: {
                        beginAtZero: true,
                    }
                }]
            }
        }
    });
</script>