<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Daftar Lembaga</title>

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.min.css">
</head>

<body>
    <div class="cotainer">
        <div class="row">
            <?php foreach ($records as $record): ?>
                <div class="col-6">
                    <div class="card">
                        <div class="card-body">
                            <table class="table">
                                <tr>
                                    <td>Username</td>
                                    <td>:</td>
                                    <td><?= $record->username ?></td>
                                </tr>
                                <tr>
                                    <td>Password</td>
                                    <td>:</td>
                                    <td><?= $record->password ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        window.print();
    </script>
</body>

</html>