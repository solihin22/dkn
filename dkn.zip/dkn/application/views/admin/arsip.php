<div class="page-inner">
	<div class="page-header">
		<h4 class="page-title"><?php echo $judul; ?></h4>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">

				<div class="card-body">
					<div class="table-responsive">
						<table id="basic-datatables" class="display table table-striped table-hover">
							<thead>
								<tr> 
									<th>Arsip Statis</th>
									<th>Arsip Kertas(as)</th>
									<th>Arsip Foto(as)</th>
									<th>Arsip Film(as)</th>
									<th>Arsip Katografi(as)</th>
									<th>Daftar Inaktif</th>
									<th>Arsip Kertas(ai)</th>
									<th>Arsip Foto(ai)</th>
									<th>Arsip Film(ai)</th>
									<th>Arsip Katografi(ai)</th>									
									<th>Tahun</th>
									<th>Aksi</th>
								</tr>
							</thead>

							<tbody>
								<?php foreach ($records	as $record) { ?>
									<tr>
										<td><?php echo $record->arsip_statis; ?></td>
										<td><?php echo $record->as_kertas; ?></td>
										<td><?php echo $record->as_foto; ?></td>
										<td><?php echo $record->as_film; ?></td>
										<td><?php echo $record->as_kartografidankearsitekturan; ?></td>
										<td><?php echo $record->arsip_inaktif; ?></td>
										<td><?php echo $record->ai_kertas; ?></td>
										<td><?php echo $record->ai_foto; ?></td>
										<td><?php echo $record->ai_film; ?></td>
										<td><?php echo $record->ai_kartografidankearsitekturan; ?></td>
										<td><?php echo $record->tahun; ?></td>
										<td>
											<a href="<?= base_url('admin/detail_arsip/' . $record->id_khasanah) ?>" class="btn btn-primary btn-sm"><i class="fa fa-search"></i></a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>