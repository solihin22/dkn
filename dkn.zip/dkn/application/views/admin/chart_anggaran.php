<div class="page-inner">
    <div class="row mt-2">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Anggaran</div>
                    <div class="card-category">Anggaran <?= $sub_data['username'] ?></div>
                    <div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
                        <canvas id="anggaran"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let anggaran = document.getElementById('anggaran').getContext('2d');
    new Chart(anggaran, {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_values($field)) ?>,
            datasets: [{
                label: 'Anggaran LKD Kearsipan',
                backgroundColor: 'rgba(54, 162, 235, .2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                data: <?= json_encode(array_values($record['kearsipan'])) ?>
            }, {
                label: 'Anggaran LKD Perpustakaan',
                backgroundColor: 'rgba(185, 122, 75, .2)',
                borderColor: 'rgba(185, 122, 75, 1)',
                borderWidth: 1,
                data: <?= json_encode(array_values($record['perpustakaan'])) ?>
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                    }
                }]
            }
        }
    });
</script>