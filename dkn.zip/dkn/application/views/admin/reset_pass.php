<div class="page-inner">
    <div class="page-header">
        <h4 class="page-title"><?php echo $judul; ?></h4>
        <?php if (@$this->session->flashdata('warning')) : ?>
            <div class="alert alert-warning" role="alert">
                <?= $this->session->flashdata('warning') ?>
            </div>
        <?php endif; ?>
    </div>
    <?php echo form_open('admin/aksi_reset_password'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <?php foreach ($records as $record) : ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Password Baru</label>
                            <?php echo form_password('new_password', '', 'placeholder="Silahkan Isi Password Baru" class="form-control" required'); ?>
                            <input type="hidden" name="username" value="<?= $record->username ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Ulangi Password Baru</label>
                            <?php echo form_password('repeat_new_password', '', 'placeholder="Silahkan Ulangi Password Baru" class="form-control" required'); ?>
                        </div>
                        <div class="form-group">
                            <?php echo form_submit('submit', 'Simpan', 'class="btn btn-primary"'); ?>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>