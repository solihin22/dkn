<div class="page-inner">
	<div class="page-header">
		<h4 class="page-title"><?php echo $judul; ?></h4>
	</div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">

				<div class="card-body">
					<div class="table-responsive">
						<table id="basic-datatables" class="display table table-striped table-hover">
							<thead>
								<tr>
									<th>Nama Pengelola</th>
									<th>Unit Kerja</th>
									<th>Jabatan</th>
									<th>No HP</th>
									<th>Nomenklatur</th>
									<th>Nama Kepala LKD</th>
									<th>Alamat</th>
									<th>Telp / Faks</th>
									<th>Email</th>
									<th>Website</th>
									<th>Status</th>
									<th>Aksi</th>
								</tr>
							</thead>

							<tbody>
								<?php foreach ($records	as $record) { ?>
									<tr>
										<td><?php echo $record->nama; ?></td>
										<td><?php echo $record->unit_kerja; ?></td>
										<td><?php echo $record->jabatan; ?></td>
										<td><?php echo $record->no_hp; ?></td>
										<td><?php echo $record->nomenklatur; ?></td>
										<td><?php echo $record->nama_kepala; ?></td>
										<td><?php echo $record->alamat; ?></td>
										<td><?php echo $record->telpfaks; ?></td>
										<td><?php echo $record->email; ?></td>
										<td><?php echo $record->website; ?></td>
										<td>
											<?php if($record->website==1):
												echo "Provinsi";
											else:
												echo "Kabupaten/Kota";
											endif;
											?>
										</td>
										<td>
											<a href="<?= base_url('admin/reset_password/' . $record->username) ?>" class="btn btn-primary btn-sm"><i class="fa fa-search"></i></a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>