<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title"><?php echo $judul;?></h4>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								
								<div class="card-body">
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead> 
												<tr>
													<th>Username</th>
													<th>Peraturan Kearsipan Daerah</th>
													<th>Peraturan Kearsipan Gubernur/Bupati/Walikota</th>
													<th>Surat Edaran / Instruksi Gubernur / Instruksi Bupati/Walikota</th>
													<th>Pedoman Tata Naskah Dinas</th>
													<th>Pedoman Jadwal Retensi Arsip</th>
													<th>Klasifikasi Arsip</th>
													<th>Klasifikasi Keamanan dan Akses</th>
													<th>Pedoman Pengelolaan Arsip </th>	
												</tr>
											</thead>
											<tbody>
											<?php foreach ($records	as $record){ ?>
												<tr>
													<td><?php echo $record->username;?></td>
													<td><?php echo $record->peraturan_daerah;?></td>
													<td><?php echo $record->peraturan_kepala;?></td>
													<td><?php echo $record->edaran;?></td>
													<td><?php echo $record->tnd;?></td>
													<td><?php echo $record->jra;?></td>
													<td><?php echo $record->klasifikasi;?></td>
													<td><?php echo $record->kka?></td>
													<td><?php echo $record->pedoman_pengolahaan_arsip?></td>
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
