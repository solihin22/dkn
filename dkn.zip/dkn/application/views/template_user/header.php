<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title><?php echo $judul;?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="<?php echo base_url() ?>assets/img/icon.ico" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="<?php echo base_url() ?>assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['<?php echo base_url() ?>assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/atlantis.min.css">

	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<div class="main-header">
			<!-- Logo Header -->
			<div class="logo-header" data-background-color="white">
				
				<a href="index.html" class="logo">
					<img src="<?php echo base_url() ?>assets/img/logo_anri.jpg" width="160" alt="navbar brand" class="navbar-brand">
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon">
						<i class="icon-menu"></i>
					</span>
				</button>
				<button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
				<div class="nav-toggle">
					<button class="btn btn-toggle toggle-sidebar">
						<i class="icon-menu"></i>
					</button>
				</div>
			</div>
			<!-- End Logo Header -->

			<!-- Navbar Header -->
			<nav class="navbar navbar-header navbar-expand-lg" data-background-color="white">
				<div class="container-fluid">
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">				
						<li class="nav-item dropdown hidden-caret">
							<a style="padding: 7px; background-color: #1a2035;color: #fff;border-radius: 5px;" href="<?php echo base_url() . 'index.php/user/logout/' ?>">LOGOUT</a>
						</li>
					</ul>
				</div>
			</nav>
			<!-- End Navbar -->
		</div>

		<!-- Sidebar -->
		<div class="sidebar sidebar-style-2" data-background-color="dark">			
			<div class="sidebar-wrapper scrollbar scrollbar-inner">
				<div class="sidebar-content">
					<div class="user">
						<div class="info">
								<span>
									<span class="user-level"> <h4>Selamat Datang <?php echo $this->session->userdata("username"); ?></h4></span>
									<span class="user-level"> <a href="<?php echo base_url()?>index.php/user/profil"><h5>Edit Profile</h5></a></span>
								</span>
							<div class="clearfix"></div>
						</div>
					</div>
					<ul class="nav nav-primary">
						<li class="nav-item <?php //echo $aktif;?>">
							<a href="<?php echo base_url().'index.php/user/' ?>">
								<i class="fas fa-home"></i>
								<p>Dashboard</p>
							</a>
						</li>
						
						<li class="nav-item">
							<a href="<?php echo base_url().'index.php/user/sarpras' ?>">
								<i class="fas fa-toolbox"></i>
								<p>Sarana Prasarana</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url().'index.php/user/sdm' ?>">
								<i class="fas fa-user"></i>
								<p>SDM</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url().'index.php/user/arsip' ?>">
								<i class="fas fa-table"></i>
								<p>Data Arsip</p>
							</a>
						</li>
						
						<li class="nav-item">
							<a href="<?php echo base_url().'index.php/user/anggaran' ?>">
								<i class="fas fa-money-bill"></i>
								<p>Anggaran</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url().'index.php/user/sistem' ?>">
								<i class="fas fa-list"></i>
								<p>Sistem Pengolahan</p>
							</a>
						</li>
						<!--<li class="nav-item">
							<a href="<?php echo base_url().'index.php/user/gnsta' ?>">
								<i class="fas fa-object-group"></i>
								<p>GNSTA</p>
							</a>
						</li>
						-->
						<li class="nav-item">
							<a href="<?php echo base_url().'index.php/user/peraturan' ?>">
								<i class="fas fa-book"></i>
								<p>Peraturan</p>
							</a>
						</li>
						
					</ul>
				</div>
			</div>
		</div>
		<!-- End Sidebar -->

		<div class="main-panel">
			<div class="content">
				